package cl.hotel.reservas.controller;

import cl.hotel.reservas.model.Reserva;
import cl.hotel.reservas.service.ReservaService;
import cl.hotel.reservas.controller.ReservaController;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ReservaControllerTest {

    @Mock
    private ReservaService service;

    @InjectMocks
    private ReservaController controller;

    @Test
    void crearReserva() {
        Map<String, Object> reservaMap = new HashMap<>();
        reservaMap.put("clienteID", 1L);
        reservaMap.put("habitacionID", 1L);
        reservaMap.put("autoID", 1L);
        reservaMap.put("fechaInicio", "2025-07-15");
        reservaMap.put("fechaFin", "2025-07-18");

        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("reserva", new Reserva());
        responseMap.put("cliente", new HashMap<>());
        responseMap.put("habitacion", new HashMap<>());
        responseMap.put("auto", new HashMap<>());
        responseMap.put("pago", new HashMap<>());
        responseMap.put("menuDetalle", new HashMap<>());

        when(service.crearReserva(reservaMap)).thenReturn(responseMap);

        ResponseEntity<?> response = controller.crearReserva(reservaMap);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        Map<String, Object> bodyContent = (Map<String, Object>) response.getBody();
        assertEquals(responseMap, bodyContent);

        verify(service, times(1)).crearReserva(reservaMap);
    }

    @Test
    void anular() {
        Long reservaID = 1L;
        Reserva reserva = new Reserva();
        reserva.setReservaID(reservaID);

        when(service.anular(reservaID)).thenReturn(reserva);

        ResponseEntity<EntityModel<Reserva>> response = controller.anular(reservaID);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        Reserva bodyContent = response.getBody().getContent();
        assertEquals(reserva, bodyContent);

        verify(service, times(1)).anular(reservaID);
    }

    @Test
    void verReserva() {
        Long reservaID = 1L;
        Map<String, Object> responseMap = new HashMap<>();
        responseMap.put("reserva", new Reserva());
        responseMap.put("cliente", new HashMap<>());
        responseMap.put("habitacion", new HashMap<>());
        responseMap.put("auto", new HashMap<>());
        responseMap.put("pago", new HashMap<>());

        when(service.verReserva(reservaID)).thenReturn(responseMap);

        ResponseEntity<EntityModel<Map<String, Object>>> response = controller.verReserva(reservaID);

        assertNotNull(response);
        assertEquals(200, response.getStatusCodeValue());
        Map<String, Object> bodyContent = response.getBody().getContent();
        assertEquals(responseMap, bodyContent);

        verify(service, times(1)).verReserva(reservaID);
    }
}
