package cl.hotel.reservas.service;

import cl.hotel.reservas.model.Reserva;
import cl.hotel.reservas.repository.ReservaRepository;
import cl.hotel.reservas.webclient.*;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ReservaServiceTest {
    @Mock
    private ReservaRepository repository;

    @Mock
    private AutoClient autoClient;

    @Mock
    private ClienteClient clienteClient;

    @Mock
    private MenuClient menuClient;

    @Mock
    private MenuDetallesClient menuDetallesClient;

    @Mock
    private PagoClient pagoClient;

    @Mock
    private HabitacionClient habitacionClient;

    @InjectMocks
    private ReservaService service;

    @Test
    void crearReserva() {
        
        Map<String, Object> reservaMap = new HashMap<>();
        reservaMap.put("clienteID", 1L);
        reservaMap.put("habitacionID", 1L);
        reservaMap.put("autoID", 1L);
        reservaMap.put("fechaInicio", "2025-07-15");
        reservaMap.put("fechaFin", "2025-07-18");

        List<Map<String, Object>> menus = new ArrayList<>();
        Map<String, Object> menuDetalle = new HashMap<>();
        menuDetalle.put("menuID", 1L);
        menuDetalle.put("cantidad", 2);
        menus.add(menuDetalle);
        reservaMap.put("menus", menus);

       
        Map<String, Object> cliente = new HashMap<>();
        cliente.put("activo", true);
        when(clienteClient.getClienteById(1L)).thenReturn(cliente);

        
        Map<String, Object> habitacion = new HashMap<>();
        habitacion.put("activo", true);
        habitacion.put("valorPorDia", 100);
        when(habitacionClient.getHabitacionById(1L)).thenReturn(habitacion);

        
        Map<String, Object> auto = new HashMap<>();
        auto.put("activo", true);
        auto.put("valor", 50);
        when(autoClient.getAutoById(1L)).thenReturn(auto);

        Map<String, Object> menu = new HashMap<>();
        menu.put("valor", 20);
        when(menuClient.getMenuById(1L)).thenReturn(menu);

        Map<String, Object> pago = new HashMap<>();
        pago.put("pagoID", 1L);
        when(pagoClient.crearPago(any())).thenReturn(pago);

        pago.put("pagado", false);
        lenient().when(pagoClient.getPagoById(1L)).thenReturn(pago);

        Map<String, Object> responseMenu = new HashMap<>();
        Map<String, Object> embedded = new HashMap<>();
        List<Map<String, Object>> menuDetalleList = new ArrayList<>();
        menuDetalleList.add(new HashMap<>());
        embedded.put("menuDetalleList", menuDetalleList);
        responseMenu.put("_embedded", embedded);
        when(menuDetallesClient.crearMenuReserva(any(), anyLong())).thenReturn(responseMenu);

        
        when(repository.save(any(Reserva.class))).thenAnswer(invocation -> {
            Reserva r = invocation.getArgument(0);
            r.setReservaID(1L);
            r.setPagoID(1L);
            return r;
        });

       
        Map<String, Object> response = service.crearReserva(reservaMap);

        
        assertNotNull(response);
        assertTrue(response.containsKey("reserva"));
        assertTrue(response.containsKey("habitacion"));
        assertTrue(response.containsKey("menuDetalle"));
        assertTrue(response.containsKey("auto"));
        assertTrue(response.containsKey("cliente"));
        assertTrue(response.containsKey("pago"));

        Reserva reservaResponse = (Reserva) response.get("reserva");
        assertEquals(1L, reservaResponse.getReservaID());
        assertEquals(1L, reservaResponse.getClienteID());
        assertEquals(1L, reservaResponse.getHabitacionID());
        assertEquals(1L, reservaResponse.getAutoID());
    }
    
    @Test
    void anularReserva() {
        Long reservaID = 1L;

        Reserva reserva = new Reserva();
        reserva.setReservaID(reservaID);
        reserva.setPagoID(1L);
        reserva.setAnulado(false);

        
        when(repository.findById(reservaID)).thenReturn(Optional.of(reserva));

       
        Map<String, Object> pago = new HashMap<>();
        pago.put("pagado", false);
        when(pagoClient.getPagoById(1L)).thenReturn(pago);

        
        when(repository.save(any(Reserva.class))).thenAnswer(invocation -> {
            Reserva r = invocation.getArgument(0);
            return r;
        });

        
        Reserva result = service.anular(reservaID);

        
        assertNotNull(result);
        assertTrue(result.getAnulado());
        assertEquals(reservaID, result.getReservaID());
    }
    @Test
    void verReserva() {
        Long reservaID = 1L;

        Reserva reserva = new Reserva();
        reserva.setReservaID(reservaID);
        reserva.setClienteID(1L);
        reserva.setHabitacionID(1L);
        reserva.setAutoID(1L);
        reserva.setPagoID(1L);
        reserva.setAnulado(false);
        reserva.setFechaInicio(java.time.LocalDate.of(2025, 7, 15));
        reserva.setFechaFin(java.time.LocalDate.of(2025, 7, 18));

        when(repository.findById(reservaID)).thenReturn(Optional.of(reserva));

        Map<String, Object> cliente = new HashMap<>();
        cliente.put("clienteID", 1L);
        cliente.put("activo", true);
        when(clienteClient.getClienteById(1L)).thenReturn(cliente);

        Map<String, Object> habitacion = new HashMap<>();
        habitacion.put("habitacionID", 1L);
        habitacion.put("activo", true);
        when(habitacionClient.getHabitacionById(1L)).thenReturn(habitacion);

        Map<String, Object> auto = new HashMap<>();
        auto.put("autoID", 1L);
        auto.put("activo", true);
        when(autoClient.getAutoById(1L)).thenReturn(auto);

        Map<String, Object> pago = new HashMap<>();
        pago.put("pagoID", 1L);
        pago.put("pagado", false);
        when(pagoClient.getPagoById(1L)).thenReturn(pago);

        Map<String, Object> response = service.verReserva(reservaID);

        assertNotNull(response);
        assertTrue(response.containsKey("reserva"));
        assertTrue(response.containsKey("cliente"));
        assertTrue(response.containsKey("habitacion"));
        assertTrue(response.containsKey("auto"));
        assertTrue(response.containsKey("pago"));

        Reserva reservaResponse = (Reserva) response.get("reserva");
        assertEquals(reservaID, reservaResponse.getReservaID());
        assertEquals(1L, reservaResponse.getClienteID());
        assertEquals(1L, reservaResponse.getHabitacionID());
        assertEquals(1L, reservaResponse.getAutoID());
        assertEquals(1L, reservaResponse.getPagoID());
    }
}

