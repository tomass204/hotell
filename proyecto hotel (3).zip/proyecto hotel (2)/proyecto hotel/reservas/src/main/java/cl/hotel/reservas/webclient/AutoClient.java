package cl.hotel.reservas.webclient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;


@Component
public class AutoClient {

    private final WebClient webClient;

    public AutoClient(@Value("${auto-service.url}") String autoServiceUrl){
        this.webClient = WebClient.builder().baseUrl(autoServiceUrl).build();
    }

    public Map<String, Object> getAutoById(Long autoID){
        return this.webClient.get()
                .uri("/{autoID}", autoID)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(),
                        response -> response.bodyToMono(String.class)
                                .map(body -> new RuntimeException("Auto no encontrado")))
                .bodyToMono(Map.class).block();
    }

}
