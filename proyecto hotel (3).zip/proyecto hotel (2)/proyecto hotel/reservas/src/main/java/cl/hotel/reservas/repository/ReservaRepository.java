package cl.hotel.reservas.repository;

import cl.hotel.reservas.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ReservaRepository extends JpaRepository<Reserva,Long> {

    java.util.List<Reserva> findByHabitacionIDAndFechaInicioLessThanEqualAndFechaFinGreaterThanEqual(Long habitacionID, java.time.LocalDate fechaFin, java.time.LocalDate fechaInicio);

}
