package cl.hotel.reservas.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "reservas")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa una reserva en el sistema")
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "reserva_id")
    @Schema(description = "Identificador único de la reserva", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long reservaID;

    @Column(name = "cliente_id", nullable = false)
    @Schema(description = "Identificador del cliente que realiza la reserva", example = "10", required = true)
    private Long clienteID;

    @Column(name = "habitacion_id", nullable = false)
    @Schema(description = "Identificador de la habitación reservada", example = "5", required = true)
    private Long habitacionID;

    @Column(name = "auto_id", nullable = false)
    @Schema(description = "Identificador del auto reservado", example = "3", required = true)
    private Long autoID;

    @Column(name = "pago_id", nullable = false)
    @Schema(description = "Identificador del pago asociado a la reserva", example = "7", required = true)
    private Long pagoID;

    @Column(name = "fecha_inicio", nullable = false)
    @Schema(description = "Fecha de inicio de la reserva", example = "2025-07-01", required = true)
    private LocalDate fechaInicio;

    @Column(name = "fecha_fin", nullable = false)
    @Schema(description = "Fecha de fin de la reserva", example = "2025-07-05", required = true)
    private LocalDate fechaFin;

    @Column(nullable = false)
    @Schema(description = "Indica si la reserva está anulada (true) o activa (false)", example = "false", required = true)
    private Boolean anulado;
}
