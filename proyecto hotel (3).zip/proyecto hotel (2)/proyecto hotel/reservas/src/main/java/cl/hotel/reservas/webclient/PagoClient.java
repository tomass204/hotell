package cl.hotel.reservas.webclient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

@Component
public class PagoClient {

    private final WebClient webClient;

    public PagoClient(@Value("${pago-service.url}") String pagoServiceUrl){
        this.webClient = WebClient.builder().baseUrl(pagoServiceUrl).build();
    }

    public Map<String, Object> getPagoById(Long pagoID){
        return this.webClient.get()
                .uri("/{pagoID}", pagoID)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(),
                        response -> response.bodyToMono(String.class)
                                .map(body -> new RuntimeException("Pago no encontrado")))
                .bodyToMono(Map.class).block();
    }

    public Map<String, Object> crearPago(Map<String, Object> pago){
        return this.webClient.post()
                .uri("")
                .bodyValue(pago)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(),
                        response -> response.bodyToMono(String.class)
                                .map(body -> new RuntimeException("Error al crear pago.")))
                .bodyToMono(Map.class).block();
    }


}
