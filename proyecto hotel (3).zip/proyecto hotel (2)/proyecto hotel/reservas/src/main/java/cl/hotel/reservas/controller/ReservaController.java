package cl.hotel.reservas.controller;

import cl.hotel.reservas.model.Reserva;
import cl.hotel.reservas.service.ReservaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/reservas")
public class ReservaController {

    @Autowired
    private ReservaService service;


    @Operation(summary = "Permite crear una reserva con sus detalles")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Recibe un Map<String, Object> con los datos de la reserva y devuelve un mapa con información relevante de la reserva creada",
        content = @Content(schema = @Schema(implementation = Map.class))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "Datos inválidos para crear la reserva"
    )
})
@PostMapping
public ResponseEntity<?> crearReserva(@RequestBody Map<String, Object> reserva) {
    try {
        Map<String, Object> resultado = service.crearReserva(reserva);
        Long id = (Long) resultado.get("reservaID");
        EntityModel<Map<String, Object>> recurso = EntityModel.of(resultado);
        if (id != null) {
            recurso.add(linkTo(methodOn(ReservaController.class).verReserva(id)).withRel("ver"));
            recurso.add(linkTo(methodOn(ReservaController.class).anular(id)).withRel("anular"));
        }
        return ResponseEntity.ok(recurso);
    } catch (RuntimeException e) {
        return ResponseEntity.badRequest().body(e.getMessage());
    }
}



    

    @Operation(summary = "Permite anular una reserva existente por su ID")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Actualiza el estado de la reserva identificada por su ID para marcarla como anulada y devuelve la reserva actualizada",
        content = @Content(schema = @Schema(implementation = Reserva.class))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido o la reserva no puede ser anulada"
    ),
    @ApiResponse(
        responseCode = "404",
        description = "Reserva no encontrada con el ID proporcionado"
    )
})
@PatchMapping("/{reservaID}")
public ResponseEntity<EntityModel<Reserva>> anular(@PathVariable Long reservaID) {
    Reserva anulado = service.anular(reservaID);
    EntityModel<Reserva> recurso = EntityModel.of(anulado);
    recurso.add(linkTo(methodOn(ReservaController.class).verReserva(reservaID)).withRel("ver"));
    recurso.add(linkTo(ReservaController.class).slash("").withRel("crear"));
    return ResponseEntity.ok(recurso);
}





    @Operation(summary = "Permite obtener los detalles completos de una reserva por su ID")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Devuelve un mapa con información detallada de la reserva identificada por su ID",
        content = @Content(schema = @Schema(implementation = Map.class))
    ),
    @ApiResponse(
        responseCode = "404",
        description = "Reserva no encontrada con el ID proporcionado"
    )
})

@GetMapping("/{reservaID}")
public ResponseEntity<EntityModel<Map<String, Object>>> verReserva(@PathVariable Long reservaID) {
    Map<String, Object> detalle = service.verReserva(reservaID);
    if (detalle == null || detalle.isEmpty()) {
        return ResponseEntity.notFound().build();
    }
    EntityModel<Map<String, Object>> recurso = EntityModel.of(detalle);
    recurso.add(linkTo(methodOn(ReservaController.class).verReserva(reservaID)).withSelfRel());
    recurso.add(linkTo(methodOn(ReservaController.class).anular(reservaID)).withRel("anular"));
    recurso.add(linkTo(ReservaController.class).slash("").withRel("crear"));
    return ResponseEntity.ok(recurso);
}


}
