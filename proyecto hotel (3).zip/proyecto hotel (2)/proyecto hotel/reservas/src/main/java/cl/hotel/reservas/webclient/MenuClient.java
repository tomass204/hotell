package cl.hotel.reservas.webclient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

@Component
public class MenuClient {

    private final WebClient webClient;

    public MenuClient(@Value("${menu-service.url}") String menuServiceUrl){
        this.webClient = WebClient.builder().baseUrl(menuServiceUrl).build();
    }

    public Map<String, Object> getMenuById(Long menuID){
        return this.webClient.get()
                .uri("/{menuID}", menuID)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(),
                        response -> response.bodyToMono(String.class)
                                .map(body -> new RuntimeException("Menu no encontrado")))
                .bodyToMono(Map.class).block();
    }

}
