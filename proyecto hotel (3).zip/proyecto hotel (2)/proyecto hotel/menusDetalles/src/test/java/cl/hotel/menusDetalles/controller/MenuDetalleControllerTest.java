package cl.hotel.menusDetalles.controller;

import cl.hotel.menusDetalles.model.MenuDetalle;
import cl.hotel.menusDetalles.service.MenuDetalleService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(MenuDetalleController.class)
class MenuDetalleControllerTest {

    @MockBean
    private MenuDetalleService service;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void crearMenuDetalle() throws Exception {
        MenuDetalle menuDetalle = new MenuDetalle();
        menuDetalle.setMenuDetalleID(10L);
        menuDetalle.setReservaID(1L);
        menuDetalle.setMenuID(2L);
        menuDetalle.setCantidad(3);

        when(service.crear(any(MenuDetalle.class))).thenReturn(menuDetalle);

        String json = """
            {
                "reservaID": 1,
                "menuID": 2,
                "cantidad": 3
            }
            """;

        try {
            mockMvc.perform(post("/api/hotel/v1/menu-detalles")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.menuDetalleID").value(10))
                .andExpect(jsonPath("$.reservaID").value(1))
                .andExpect(jsonPath("$.menuID").value(2))
                .andExpect(jsonPath("$.cantidad").value(3));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void crearMenuReserva() throws Exception {
        List<MenuDetalle> menuDetalles = new ArrayList<>();

        MenuDetalle detalle1 = new MenuDetalle();
        detalle1.setMenuDetalleID(10L);
        detalle1.setReservaID(100L);
        detalle1.setMenuID(1L);
        detalle1.setCantidad(2);

        MenuDetalle detalle2 = new MenuDetalle();
        detalle2.setMenuDetalleID(11L);
        detalle2.setReservaID(100L);
        detalle2.setMenuID(2L);
        detalle2.setCantidad(3);

        menuDetalles.add(detalle1);
        menuDetalles.add(detalle2);

        when(service.crearMenuReserva(anyList(), eq(100L))).thenReturn(menuDetalles);

        String json = """
            [
                {"menuID": 1, "cantidad": 2},
                {"menuID": 2, "cantidad": 3}
            ]
            """;

        try {
            mockMvc.perform(post("/api/hotel/v1/menu-detalles/reserva/100")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))

                    .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].menuDetalleID").value(10))
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].reservaID").value(100))
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].menuID").value(1))
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].cantidad").value(2))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].menuDetalleID").value(11))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].reservaID").value(100))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].menuID").value(2))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].cantidad").value(3));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void editarMenuDetalle() throws Exception {
        MenuDetalle detalle = new MenuDetalle();
        detalle.setMenuDetalleID(10L);
        detalle.setReservaID(1L);
        detalle.setMenuID(2L);
        detalle.setCantidad(3);

        when(service.editar(any(MenuDetalle.class), eq(10L))).thenReturn(detalle);

        String json = """
            {
                "reservaID": 1,
                "menuID": 2,
                "cantidad": 3
            }
            """;

        try {
            mockMvc.perform(put("/api/hotel/v1/menu-detalles/10")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.menuDetalleID").value(10))
                .andExpect(jsonPath("$.reservaID").value(1))
                .andExpect(jsonPath("$.menuID").value(2))
                .andExpect(jsonPath("$.cantidad").value(3));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void eliminarMenuDetalle() throws Exception {
        MenuDetalle detalle = new MenuDetalle();
        detalle.setMenuDetalleID(10L);
        detalle.setReservaID(1L);
        detalle.setMenuID(2L);
        detalle.setCantidad(3);

        when(service.eliminar(10L)).thenReturn(detalle);

        try {
            mockMvc.perform(delete("/api/hotel/v1/menu-detalles/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.menuDetalleID").value(10));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void verMenuDetalle() throws Exception {
        MenuDetalle detalle = new MenuDetalle();
        detalle.setMenuDetalleID(10L);
        detalle.setReservaID(1L);
        detalle.setMenuID(2L);
        detalle.setCantidad(3);

        when(service.ver(10L)).thenReturn(detalle);

        try {
            mockMvc.perform(get("/api/hotel/v1/menu-detalles/10"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.menuDetalleID").value(10))
                .andExpect(jsonPath("$.reservaID").value(1))
                .andExpect(jsonPath("$.menuID").value(2))
                .andExpect(jsonPath("$.cantidad").value(3));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void listarPorReserva() throws Exception {
        List<MenuDetalle> menuDetalles = new ArrayList<>();

        MenuDetalle detalle1 = new MenuDetalle();
        detalle1.setMenuDetalleID(10L);
        detalle1.setReservaID(1L);
        detalle1.setMenuID(1L);
        detalle1.setCantidad(2);

        MenuDetalle detalle2 = new MenuDetalle();
        detalle2.setMenuDetalleID(11L);
        detalle2.setReservaID(1L);
        detalle2.setMenuID(2L);
        detalle2.setCantidad(3);

        menuDetalles.add(detalle1);
        menuDetalles.add(detalle2);

        when(service.listarPorReserva(1L)).thenReturn(menuDetalles);

        try {
            mockMvc.perform(get("/api/hotel/v1/menu-detalles/reserva/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].menuDetalleID").value(10))
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].reservaID").value(1))
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].menuID").value(1))
                .andExpect(jsonPath("$._embedded.menuDetalleList[0].cantidad").value(2))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].menuDetalleID").value(11))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].reservaID").value(1))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].menuID").value(2))
                .andExpect(jsonPath("$._embedded.menuDetalleList[1].cantidad").value(3));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
