package cl.hotel.menusDetalles.service;


import java.util.ArrayList;
import java.util.List;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import cl.hotel.menusDetalles.repository.MenuDetalleRepository;
import cl.hotel.menusDetalles.model.MenuDetalle;

@ExtendWith(MockitoExtension.class)
public class MenuDetalleServiceTest {
    @Mock
    private MenuDetalleRepository repositorio;

    @InjectMocks
    private MenuDetalleService service;

    @Test
    void crearMenuDetalle(){
        MenuDetalle menuDetalle = new MenuDetalle();
        menuDetalle.setMenuDetalleID(null);
        menuDetalle.setReservaID(1L);
        menuDetalle.setMenuID(2L);
        menuDetalle.setCantidad(3);

        Mockito.when(repositorio.save(ArgumentMatchers.any(MenuDetalle.class)))
            .thenAnswer(invocation -> {
                MenuDetalle arg = invocation.getArgument(0);
                arg.setMenuDetalleID(10L);
                return arg;
            });

        MenuDetalle result = service.crear(menuDetalle);

        org.junit.jupiter.api.Assertions.assertNotNull(result);
        org.junit.jupiter.api.Assertions.assertEquals(10L, result.getMenuDetalleID());
        org.junit.jupiter.api.Assertions.assertEquals(1L, result.getReservaID());
        org.junit.jupiter.api.Assertions.assertEquals(2L, result.getMenuID());
        org.junit.jupiter.api.Assertions.assertEquals(3, result.getCantidad());
    }

        @Test
        void crearMenuReservaDetalle(){
            List<MenuDetalle> menuDetalles = new java.util.ArrayList<>();

            MenuDetalle detalle1 = new MenuDetalle();
            detalle1.setMenuDetalleID(null);
            detalle1.setMenuID(1L);
            detalle1.setCantidad(2);

            MenuDetalle detalle2 = new MenuDetalle();
            detalle2.setMenuDetalleID(null);
            detalle2.setMenuID(2L);
            detalle2.setCantidad(3);

            menuDetalles.add(detalle1);
            menuDetalles.add(detalle2);

            Long reservaID = 100L;

            Mockito.when(repositorio.saveAll(ArgumentMatchers.anyList()))
                .thenAnswer(invocation -> {
                    List<MenuDetalle> arg = invocation.getArgument(0);
                    long idCounter = 10L;
                    for (MenuDetalle md : arg) {
                        md.setMenuDetalleID(idCounter++);
                        md.setReservaID(reservaID);
                    }
                    return arg;
                });

            List<MenuDetalle> result = service.crearMenuReserva(menuDetalles, reservaID);

            org.junit.jupiter.api.Assertions.assertNotNull(result);
            org.junit.jupiter.api.Assertions.assertEquals(2, result.size());

            for (int i = 0; i < result.size(); i++) {
                MenuDetalle md = result.get(i);
                org.junit.jupiter.api.Assertions.assertEquals(10L + i, md.getMenuDetalleID());
                org.junit.jupiter.api.Assertions.assertEquals(reservaID, md.getReservaID());
                org.junit.jupiter.api.Assertions.assertEquals(menuDetalles.get(i).getMenuID(), md.getMenuID());
                org.junit.jupiter.api.Assertions.assertEquals(menuDetalles.get(i).getCantidad(), md.getCantidad());
            }
        }

        @Test
        void editarMenuDetalle(){
            MenuDetalle detalle = new MenuDetalle();
            detalle.setMenuDetalleID(null);
            detalle.setReservaID(1L);
            detalle.setMenuID(2L);
            detalle.setCantidad(3);

            Long menuDetalleID = 10L;

           Mockito.when(repositorio.save(ArgumentMatchers.any(MenuDetalle.class)))
                .thenAnswer(invocation -> {
                    MenuDetalle arg = invocation.getArgument(0);
                    arg.setMenuDetalleID(menuDetalleID);
                    return arg;
                });

            MenuDetalle result = service.editar(detalle, menuDetalleID);

            org.junit.jupiter.api.Assertions.assertNotNull(result);
            org.junit.jupiter.api.Assertions.assertEquals(menuDetalleID, result.getMenuDetalleID());
            org.junit.jupiter.api.Assertions.assertEquals(1L, result.getReservaID());
            org.junit.jupiter.api.Assertions.assertEquals(2L, result.getMenuID());
            org.junit.jupiter.api.Assertions.assertEquals(3, result.getCantidad());
        }
        @Test
        void eliminarMenuDetalle(){
            Long menuDetalleID = 999L;

            Mockito.when(repositorio.findById(menuDetalleID))
                .thenReturn(java.util.Optional.empty());

            org.junit.jupiter.api.Assertions.assertThrows(RuntimeException.class, () -> {
                service.eliminar(menuDetalleID);
            });
        }


        @Test
        void verMenuDetalle(){
            Long menuDetalleID = 999L;

            Mockito.when(repositorio.findById(menuDetalleID))
                .thenReturn(java.util.Optional.empty());

            org.junit.jupiter.api.Assertions.assertThrows(RuntimeException.class, () -> {
                service.ver(menuDetalleID);
            });
        }

        @Test
        void listaPorReservaMenuDetalle(){
            Long reservaID = 1L;

            List<MenuDetalle> menuDetalles = new ArrayList<>();

            MenuDetalle detalle1 = new MenuDetalle();
            detalle1.setMenuDetalleID(10L);
            detalle1.setReservaID(reservaID);
            detalle1.setMenuID(1L);
            detalle1.setCantidad(2);

            MenuDetalle detalle2 = new MenuDetalle();
            detalle2.setMenuDetalleID(11L);
            detalle2.setReservaID(reservaID);
            detalle2.setMenuID(2L);
            detalle2.setCantidad(3);

            menuDetalles.add(detalle1);
            menuDetalles.add(detalle2);

            Mockito.when(repositorio.findAllByReservaID(reservaID))
                .thenReturn(menuDetalles);

            List<MenuDetalle> result = service.listarPorReserva(reservaID);

            org.junit.jupiter.api.Assertions.assertNotNull(result);
            org.junit.jupiter.api.Assertions.assertEquals(2, result.size());

            for (int i = 0; i < result.size(); i++) {
                MenuDetalle md = result.get(i);
                org.junit.jupiter.api.Assertions.assertEquals(menuDetalles.get(i).getMenuDetalleID(), md.getMenuDetalleID());
                org.junit.jupiter.api.Assertions.assertEquals(menuDetalles.get(i).getReservaID(), md.getReservaID());
                org.junit.jupiter.api.Assertions.assertEquals(menuDetalles.get(i).getMenuID(), md.getMenuID());
                org.junit.jupiter.api.Assertions.assertEquals(menuDetalles.get(i).getCantidad(), md.getCantidad());
            }
        }
}
