package cl.hotel.menusDetalles.service;

import cl.hotel.menusDetalles.model.MenuDetalle;
import cl.hotel.menusDetalles.repository.MenuDetalleRepository;
import cl.hotel.menusDetalles.repository.MenuRepositpory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class MenuDetalleService {

    @Autowired
    private MenuDetalleRepository repository;

    @Autowired
    private MenuRepositpory menuRepositpory;

    public MenuDetalle crear(MenuDetalle menuDetalle) {
        // Check if MenuDetalle with same menuID and reservaID exists
        if (repository.findByMenuIDAndReservaID(menuDetalle.getMenuID(), menuDetalle.getReservaID()).isPresent()) {
            throw new RuntimeException("Detalle de menú ya existe para el menú y reserva especificados.");
        }
        menuDetalle.setMenuDetalleID(null);
        menuDetalle = repository.save(menuDetalle);
        menuDetalle.setMenu(menuRepositpory.findById(menuDetalle.getMenuID())
                .orElseThrow(() -> new RuntimeException("Error al traer menu")));
        return menuDetalle;

    }

    public List<MenuDetalle> crearMenuReserva(List<MenuDetalle> menuDetalle, Long reservaID) {
        menuDetalle.forEach(detalle -> {
            detalle.setReservaID(reservaID);
            detalle.setMenuDetalleID(null);
        });
        menuDetalle = repository.saveAll(menuDetalle);
        menuDetalle.forEach(detalle -> {
            detalle.setMenu(menuRepositpory.findById(detalle.getMenuID())
                    .orElseThrow(() -> new RuntimeException("Error al traer menu")));
        });
        return menuDetalle;

    }

    public MenuDetalle editar(MenuDetalle menuDetalle, Long menuDetalleID) {
        menuDetalle.setMenuDetalleID(menuDetalleID);
        menuDetalle = repository.save(menuDetalle);
        menuDetalle.setMenu(menuRepositpory.findById(menuDetalle.getMenuID())
                .orElseThrow(() -> new RuntimeException("Error al traer menu")));
        return menuDetalle;
    }

    public MenuDetalle eliminar(Long menuDetalleID) {
        Optional<MenuDetalle> menuDetalleOptional = repository.findById(menuDetalleID);
        if (!menuDetalleOptional.isPresent()) {
            throw new RuntimeException("No existe el detalle a eliminar.");
        }
        MenuDetalle menuDetalle = menuDetalleOptional.get();
        repository.deleteById(menuDetalleID);
        return menuDetalle;
    }

    public MenuDetalle ver(Long menuDetalleID) {
        Optional<MenuDetalle> menuDetalleOptional = repository.findById(menuDetalleID);
        if (!menuDetalleOptional.isPresent()) {
            throw new RuntimeException("No existe el detalle.");
        }
        return menuDetalleOptional.get();
    }

    public List<MenuDetalle> listarPorReserva(Long reservaID) {
        return repository.findAllByReservaID(reservaID);
    }

}
