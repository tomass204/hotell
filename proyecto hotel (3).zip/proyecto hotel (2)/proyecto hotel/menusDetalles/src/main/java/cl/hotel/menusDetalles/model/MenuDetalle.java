package cl.hotel.menusDetalles.model;

import java.time.LocalDate;

import io.swagger.v3.oas.annotations.media.Schema; // 🔁 Importación para Swagger

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "menusdetalles")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa el detalle de un menú asignado a una reserva")
public class MenuDetalle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "menu_detalle_id")
    @Schema(description = "ID único del detalle del menú", example = "1")
    private Long menuDetalleID;

    @Column(name = "menu_id", nullable = false)
    @Schema(description = "ID del menú relacionado", example = "5", required = true)
    private Long menuID;

    @Column(name = "reserva_id", nullable = false)
    @Schema(description = "ID de la reserva relacionada", example = "12", required = true)
    private Long reservaID;

    @Column(nullable = false)
    @Schema(description = "Fecha en la que se asigna el menú", example = "2025-07-01", required = true)
    private LocalDate fecha;

    @Column(nullable = false)
    @Schema(description = "Cantidad de menús asignados", example = "3", required = true)
    private Integer cantidad;

    @ManyToOne
    @JoinColumn(name = "menu_id", insertable = false, updatable = false)
    @Schema(description = "Objeto menú relacionado (solo lectura)")
    private Menu menu;
}

