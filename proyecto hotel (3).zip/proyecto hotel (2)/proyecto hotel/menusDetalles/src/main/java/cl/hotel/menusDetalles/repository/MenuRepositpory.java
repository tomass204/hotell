package cl.hotel.menusDetalles.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.hotel.menusDetalles.model.Menu;

public interface MenuRepositpory extends JpaRepository<Menu, Long> {

}
