package cl.hotel.menusDetalles.controller;


import cl.hotel.menusDetalles.model.MenuDetalle;
import cl.hotel.menusDetalles.service.MenuDetalleService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;

@RestController
@RequestMapping("/api/hotel/v1/menu-detalles")
public class MenuDetalleController {

    @Autowired
    private MenuDetalleService service;

    //Crea un nuevo menu detalle


    @Operation(summary = "Permite crear un detalle de menú con sus características")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Recibe un objeto MenuDetalle con las características del detalle y lo registra en el sistema",
        content = @Content(schema = @Schema(implementation = MenuDetalle.class))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "Datos inválidos para crear el detalle de menú"
    )
})
  @PostMapping
    public ResponseEntity<?> crear(@RequestBody MenuDetalle menuDetalle) {
        try {
            MenuDetalle creado = service.crear(menuDetalle);
            EntityModel<MenuDetalle> recurso = EntityModel.of(creado);
            recurso.add(linkTo(methodOn(MenuDetalleController.class).ver(creado.getMenuDetalleID())).withRel("ver"));
            recurso.add(linkTo(methodOn(MenuDetalleController.class).editar(creado, creado.getMenuDetalleID())).withRel("editar"));
            recurso.add(linkTo(methodOn(MenuDetalleController.class).eliminar(creado.getMenuDetalleID())).withRel("eliminar"));
            return ResponseEntity.ok(recurso);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }




    //Crea un menu reserva con muchos detalles 

@Operation(summary = "Asocia múltiples detalles de menú a una reserva específica")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Recibe una lista de objetos MenuDetalle, los guarda en la base de datos y los vincula a la reserva con el ID especificado",
        content = @Content(array = @ArraySchema(schema = @Schema(implementation = MenuDetalle.class)))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "El ID de reserva es inválido o la lista de detalles contiene errores"
    )
})


   @PostMapping("/reserva/{reservaID}")
   public ResponseEntity<CollectionModel<EntityModel<MenuDetalle>>> crearMenuReserva(@RequestBody List<MenuDetalle> menuDetalle, @PathVariable Long reservaID) {
        List<MenuDetalle> creados = service.crearMenuReserva(menuDetalle, reservaID);
        List<EntityModel<MenuDetalle>> recursos = creados.stream()
            .map(md -> EntityModel.of(md,
                linkTo(methodOn(MenuDetalleController.class).ver(md.getMenuDetalleID())).withRel("ver"),
                linkTo(methodOn(MenuDetalleController.class).editar(md, md.getMenuDetalleID())).withRel("editar"),
                linkTo(methodOn(MenuDetalleController.class).eliminar(md.getMenuDetalleID())).withRel("eliminar")))
            .toList();
        CollectionModel<EntityModel<MenuDetalle>> collection = CollectionModel.of(recursos);
        collection.add(linkTo(methodOn(MenuDetalleController.class).listarPorReserva(reservaID)).withRel("listar-por-reserva"));
        return ResponseEntity.ok(collection);
    }

    @PostMapping("/reserva_old/{reservaID}")
    public ResponseEntity<List<MenuDetalle>> crearMenuReserva_old(@RequestBody List<MenuDetalle> menuDetalle, @PathVariable Long reservaID) {
        return ResponseEntity.ok(service.crearMenuReserva(menuDetalle, reservaID));
    }






    //EditaUnMenuExistente

    @Operation(summary = "Permite editar un detalle de menú existente")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Recibe un objeto MenuDetalle con los nuevos datos y actualiza el registro correspondiente identificado por su ID",
        content = @Content(schema = @Schema(implementation = MenuDetalle.class))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "Datos inválidos o ID de detalle de menú no existente"
    )
})


   @PutMapping("/{menuDetalleID}")
    public ResponseEntity<EntityModel<MenuDetalle>> editar(@RequestBody MenuDetalle menuDetalle, @PathVariable Long menuDetalleID) {
        MenuDetalle actualizado = service.editar(menuDetalle, menuDetalleID);
        EntityModel<MenuDetalle> recurso = EntityModel.of(actualizado);
        recurso.add(linkTo(methodOn(MenuDetalleController.class).ver(menuDetalleID)).withRel("ver"));
        recurso.add(linkTo(methodOn(MenuDetalleController.class).eliminar(menuDetalleID)).withRel("eliminar"));
        return ResponseEntity.ok(recurso);
    }





    //borra un detalle de menú

    @Operation(summary = "Permite eliminar un detalle de menú existente por su ID")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Elimina el detalle de menú identificado por su ID y devuelve el objeto eliminado",
        content = @Content(schema = @Schema(implementation = MenuDetalle.class))
    ),
    @ApiResponse(
        responseCode = "404",
        description = "No se encontró un detalle de menú con el ID proporcionado"
    )
})

  @DeleteMapping("/{menuDetalleID}")
    public ResponseEntity<EntityModel<MenuDetalle>> eliminar(@PathVariable Long menuDetalleID) {
        MenuDetalle eliminado = service.eliminar(menuDetalleID);
        EntityModel<MenuDetalle> recurso = EntityModel.of(eliminado);
        recurso.add(linkTo(methodOn(MenuDetalleController.class).listarPorReserva(eliminado.getReservaID())).withRel("listar-por-reserva"));
        return ResponseEntity.ok(recurso);
    }





    //Muestra el detalle del menu por ID

    @Operation(summary = "Permite obtener un detalle de menú por su ID")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Devuelve los detalles completos del MenuDetalle solicitado",
        content = @Content(schema = @Schema(implementation = MenuDetalle.class))
    ),
    @ApiResponse(
        responseCode = "404",
        description = "No se encontró un detalle de menú con el ID proporcionado"
    )
})

   @GetMapping("/{menuDetalleID}")
    public ResponseEntity<EntityModel<MenuDetalle>> ver(@PathVariable Long menuDetalleID) {
        MenuDetalle encontrado = service.ver(menuDetalleID);
        EntityModel<MenuDetalle> recurso = EntityModel.of(encontrado);
        recurso.add(linkTo(methodOn(MenuDetalleController.class).editar(encontrado, menuDetalleID)).withRel("editar"));
        recurso.add(linkTo(methodOn(MenuDetalleController.class).eliminar(menuDetalleID)).withRel("eliminar"));
        recurso.add(linkTo(methodOn(MenuDetalleController.class).listarPorReserva(encontrado.getReservaID())).withRel("listar-por-reserva"));
        return ResponseEntity.ok(recurso);
    }

    




    //VerReservaIdMenu

    @Operation(summary = "Permite listar todos los detalles de menú asociados a una reserva específica")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Devuelve una lista con todos los MenuDetalle vinculados a la reserva indicada por su ID",
        content = @Content(array = @ArraySchema(schema = @Schema(implementation = MenuDetalle.class)))
    ),
    @ApiResponse(
        responseCode = "404",
        description = "No se encontró una reserva con el ID proporcionado"
    )
})

  @GetMapping("/reserva/{reservaID}")
    public ResponseEntity<CollectionModel<EntityModel<MenuDetalle>>> listarPorReserva(@PathVariable Long reservaID) {
        List<MenuDetalle> detalles = service.listarPorReserva(reservaID);
        List<EntityModel<MenuDetalle>> recursos = detalles.stream()
            .map(md -> EntityModel.of(md,
                linkTo(methodOn(MenuDetalleController.class).ver(md.getMenuDetalleID())).withRel("ver"),
                linkTo(methodOn(MenuDetalleController.class).editar(md, md.getMenuDetalleID())).withRel("editar"),
                linkTo(methodOn(MenuDetalleController.class).eliminar(md.getMenuDetalleID())).withRel("eliminar")))
            .toList();
        CollectionModel<EntityModel<MenuDetalle>> collection = CollectionModel.of(recursos);
        collection.add(linkTo(methodOn(MenuDetalleController.class).listarPorReserva(reservaID)).withRel("self"));
        return ResponseEntity.ok(collection);
    }


}
