package cl.hotel.menusDetalles.model;

import io.swagger.v3.oas.annotations.media.Schema; // 🔁 Importación Swagger

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "menus")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa el detalle de un menú del hotel")
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "menu_id")
    @Schema(description = "ID único del menú", example = "1")
    private Long menuID;

    @Schema(description = "Nombre del menú", example = "Almuerzo Ejecutivo", required = true)
    private String nombre;

    @Schema(description = "Descripción del menú", example = "Incluye entrada, plato principal y bebida", required = true)
    private String descripcion;

    @Schema(description = "Valor del menú en pesos chilenos", example = "9500", required = true)
    private Integer valor;

    @Schema(description = "Indica si el menú está activo", example = "true", required = true)
    private Boolean activo;
}
