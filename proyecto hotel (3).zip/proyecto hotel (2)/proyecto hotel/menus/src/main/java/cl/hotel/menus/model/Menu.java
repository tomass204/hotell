package cl.hotel.menus.model;

import io.swagger.v3.oas.annotations.media.Schema; // 🔁 Importación para Swagger

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "menus")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa un menú del hotel")
public class Menu {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "menu_id")
    @Schema(description = "ID único del menú", example = "1")
    private Long menuID;

    @Column(nullable = false)
    @Schema(description = "Nombre del menú", example = "Desayuno Continental", required = true)
    private String nombre;

    @Column(nullable = false)
    @Schema(description = "Descripción del menú", example = "Incluye café, jugo, pan con mermelada", required = true)
    private String descripcion;

    @Column(nullable = false)
    @Schema(description = "Valor del menú en pesos chilenos", example = "7500", required = true)
    private Integer valor;

    @Column(nullable = false)
    @Schema(description = "Indica si el menú está activo", example = "true", required = true)
    private Boolean activo;
}

