package cl.hotel.menus.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.CollectionModel;

import cl.hotel.menus.model.Menu;
import cl.hotel.menus.service.MenuService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/menus")
public class MenuController {

    @Autowired
    private MenuService service;

    @Operation(summary = "Permite crear un menú con sus características")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Recibe un Map<String, Object> que representa las características del menú y crea uno nuevo",
            content = @Content(schema = @Schema(implementation = Menu.class))
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Datos inválidos para crear el menú"
        )
    })
    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Map<String,Object> menu){
        try {
            Menu nuevo = service.crear(menu);
            EntityModel<Menu> recurso = EntityModel.of(nuevo);
            recurso.add(linkTo(methodOn(MenuController.class).ver(nuevo.getMenuID())).withSelfRel());
            recurso.add(linkTo(methodOn(MenuController.class).editar(null, nuevo.getMenuID())).withRel("editar"));
            recurso.add(linkTo(methodOn(MenuController.class).cambiarEstado(nuevo.getMenuID(), false)).withRel("desactivar"));
            return ResponseEntity.ok(recurso);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @Operation(summary = "Permite editar un menú existente con sus datos actualizados")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Recibe un Map<String, Object> con los nuevos datos para actualizar un menú existente",
            content = @Content(schema = @Schema(implementation = Menu.class))
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Datos inválidos para actualizar el menú"
        )
    })
    @PutMapping("/{menuID}")
    public ResponseEntity<EntityModel<Menu>> editar(@RequestBody Map<String,Object> menu, @PathVariable Long menuID){
        Menu actualizado = service.editar(menu, menuID);
        EntityModel<Menu> recurso = EntityModel.of(actualizado);
        recurso.add(linkTo(methodOn(MenuController.class).ver(menuID)).withSelfRel());
        recurso.add(linkTo(methodOn(MenuController.class).cambiarEstado(menuID, false)).withRel("desactivar"));
        return ResponseEntity.ok(recurso);
    }

    @Operation(summary = "Permite cambiar el estado de un menú (activar o desactivar)")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Estado modificado correctamente", content = @Content(schema = @Schema(implementation = Menu.class))),
        @ApiResponse(responseCode = "400", description = "ID inválido o el estado no puede ser modificado")
    })
    @PatchMapping("/cambiar-estado/{menuID}")
    public ResponseEntity<EntityModel<Menu>> cambiarEstado(@PathVariable Long menuID, @RequestParam boolean activar) {
        Menu menu = activar ? service.activar(menuID) : service.desactivar(menuID);
        EntityModel<Menu> recurso = EntityModel.of(menu);
        recurso.add(linkTo(methodOn(MenuController.class).ver(menuID)).withSelfRel());
        recurso.add(linkTo(methodOn(MenuController.class).cambiarEstado(menuID, !activar)).withRel(activar ? "desactivar" : "activar"));
        return ResponseEntity.ok(recurso);
    }

    @Operation(summary = "Permite obtener un menú existente por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve los detalles completos de un menú dado su ID", content = @Content(schema = @Schema(implementation = Menu.class))),
        @ApiResponse(responseCode = "404", description = "Menú no encontrado con el ID proporcionado")
    })
    @GetMapping("/{menuID}")
    public ResponseEntity<EntityModel<Menu>> ver(@PathVariable Long menuID){
        Menu menu = service.ver(menuID);
        EntityModel<Menu> recurso = EntityModel.of(menu);
        recurso.add(linkTo(methodOn(MenuController.class).editar(null, menuID)).withRel("editar"));
        recurso.add(linkTo(methodOn(MenuController.class).cambiarEstado(menuID, false)).withRel("desactivar"));
        recurso.add(linkTo(methodOn(MenuController.class).listaMenus()).withRel("listar-todos"));
        return ResponseEntity.ok(recurso);
    }

    @Operation(summary = "Permite obtener la lista de todos los menús disponibles")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve una lista con todos los menús registrados en el sistema", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Menu.class))))
    })
    @GetMapping("/listar")
    public ResponseEntity<CollectionModel<EntityModel<Menu>>> listaMenus(){
        List<EntityModel<Menu>> menus = service.listaMenus().stream()
            .map(m -> EntityModel.of(m, linkTo(methodOn(MenuController.class).ver(m.getMenuID())).withSelfRel()))
            .toList();
        return ResponseEntity.ok(CollectionModel.of(menus,
            linkTo(methodOn(MenuController.class).listaMenus()).withSelfRel()));
    }

    @Operation(summary = "Permite obtener la lista de menús activos disponibles")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve una lista con todos los menús que están activos en el sistema", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Menu.class))))
    })
    @GetMapping("/listar-activos")
    public ResponseEntity<CollectionModel<EntityModel<Menu>>> listaMenusActivos(){
        List<EntityModel<Menu>> activos = service.listaMenusActivos().stream()
            .map(m -> EntityModel.of(m, linkTo(methodOn(MenuController.class).ver(m.getMenuID())).withSelfRel()))
            .toList();
        return ResponseEntity.ok(CollectionModel.of(activos,
            linkTo(methodOn(MenuController.class).listaMenusActivos()).withSelfRel()));
    }
}
