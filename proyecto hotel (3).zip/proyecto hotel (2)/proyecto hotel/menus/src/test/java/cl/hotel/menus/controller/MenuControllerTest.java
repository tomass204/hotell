package cl.hotel.menus.controller;

import cl.hotel.menus.model.Menu;
import cl.hotel.menus.service.MenuService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;


import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(MenuController.class)
class MenuControllerTest {

    @MockBean
    private MenuService service;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void crearMenu() throws Exception {
        Menu menu = new Menu();
        menu.setMenuID(1L);
        menu.setNombre("Lasana");
        menu.setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu.setValor(5000);
        menu.setActivo(true);

        when(service.crear(anyMap())).thenReturn(menu);

        String json = "{\n" +
                "  \"nombre\": \"Lasana\",\n" +
                "  \"descripcion\": \"La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.\",\n" +
                "  \"valor\": 5000\n" +
                "}";

        mockMvc.perform(post("/api/hotel/v1/menus")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.menuID").value(1L))
            .andExpect(jsonPath("$.nombre").value("Lasana"));
    }

    @Test
    void editarMenu() throws Exception {
        Menu menu = new Menu();
        menu.setMenuID(1L);
        menu.setNombre("Lasana");
        menu.setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu.setValor(6000);
        menu.setActivo(true);

        when(service.editar(anyMap(), eq(1L))).thenReturn(menu);

        String json = "{\n" +
                "  \"nombre\": \"Lasana\",\n" +
                "  \"descripcion\": \"La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.\",\n" +
                "  \"valor\": 6000\n" +
                "}";

        mockMvc.perform(put("/api/hotel/v1/menus/1")
                .contentType(MediaType.APPLICATION_JSON)
                .content(json))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.menuID").value(1L))
            .andExpect(jsonPath("$.valor").value(6000));
    }

    // Test combinado para activar
    @Test
    void cambiarEstadoMenu_activar() throws Exception {
        Menu menu = new Menu();
        menu.setMenuID(1L);
        menu.setActivo(true);

        when(service.activar(1L)).thenReturn(menu);

        mockMvc.perform(patch("/api/hotel/v1/menus/cambiar-estado/1")
                .param("activar", "true"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.activo").value(true));
    }

    // Test combinado para desactivar
    @Test
    void cambiarEstadoMenu_desactivar() throws Exception {
        Menu menu = new Menu();
        menu.setMenuID(1L);
        menu.setActivo(false);

        when(service.desactivar(1L)).thenReturn(menu);

        mockMvc.perform(patch("/api/hotel/v1/menus/cambiar-estado/1")
                .param("activar", "false"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.activo").value(false));
    }

    @Test
    void verMenu() throws Exception {
        Menu menu = new Menu();
        menu.setMenuID(1L);
        menu.setNombre("Lasana");
        menu.setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu.setValor(5000);
        menu.setActivo(true);

        when(service.ver(1L)).thenReturn(menu);

        mockMvc.perform(get("/api/hotel/v1/menus/1"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.menuID").value(1L))
            .andExpect(jsonPath("$.nombre").value("Lasana"));
    }

    @Test
    void listarMenus() throws Exception {
        List<Menu> menus = List.of(new Menu(), new Menu());
        menus.get(0).setMenuID(1L);
        menus.get(0).setNombre("Lasana");
        menus.get(0).setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menus.get(0).setValor(5000);
        menus.get(0).setActivo(true);

        menus.get(1).setMenuID(2L);
        menus.get(1).setNombre("Pizza");
        menus.get(1).setDescripcion("Pizza con queso y pepperoni.");
        menus.get(1).setValor(7000);
        menus.get(1).setActivo(true);

        when(service.listaMenus()).thenReturn(menus);

        mockMvc.perform(get("/api/hotel/v1/menus/listar"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$._embedded.menuList[0].menuID").value(1L))
            .andExpect(jsonPath("$._embedded.menuList[0].nombre").value("Lasana"))
            .andExpect(jsonPath("$._embedded.menuList[1].menuID").value(2L))
            .andExpect(jsonPath("$._embedded.menuList[1].nombre").value("Pizza"));
    }

    @Test
    void listarMenusActivos() throws Exception {
        List<Menu> menus = List.of(new Menu());
        menus.get(0).setMenuID(1L);
        menus.get(0).setNombre("Lasana");
        menus.get(0).setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menus.get(0).setValor(5000);
        menus.get(0).setActivo(true);

        when(service.listaMenusActivos()).thenReturn(menus);

        mockMvc.perform(get("/api/hotel/v1/menus/listar-activos"))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$._embedded.menuList[0].activo").value(true));
    }
}
