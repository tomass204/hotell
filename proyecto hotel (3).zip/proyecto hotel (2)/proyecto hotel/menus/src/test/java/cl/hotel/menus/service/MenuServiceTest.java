package cl.hotel.menus.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.Mockito.when;

import java.util.Map;
import java.util.Optional;
import java.util.List;
import java.util.ArrayList;
import java.util.HashMap;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import cl.hotel.menus.model.Menu;
import cl.hotel.menus.repository.MenuRepository;

@ExtendWith(MockitoExtension.class)
public class MenuServiceTest {
    @Mock
    private MenuRepository repository;

    @InjectMocks
    private MenuService service;

    @Test
    void crearMenu() {
        Map<String, Object> mapMenu = new HashMap<>();
        mapMenu.put("nombre", "Lasana");
        mapMenu.put("descripcion", "La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        mapMenu.put("valor", 5000);

        Menu menu = new Menu();
        menu.setMenuID(1L);
        menu.setNombre("Lasana");
        menu.setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu.setValor(5000);
        menu.setActivo(true);

        when(repository.save(ArgumentMatchers.any(Menu.class))).thenReturn(menu);

        Menu result = service.crear(mapMenu);

        assertNotNull(result);
        assertEquals(menu.getMenuID(), result.getMenuID());
        assertEquals(menu.getNombre(), result.getNombre());
        assertEquals(menu.getDescripcion(), result.getDescripcion());
        assertEquals(menu.getValor(), result.getValor());
        assertEquals(menu.getActivo(), result.getActivo());
    }

    @Test
    void editarMenu() {
        Long menuID = 1L;

        Map<String, Object> mapMenu = new HashMap<>();
        mapMenu.put("nombre", "Lasana");
        mapMenu.put("descripcion", "La lasana es un plato italiano con capas de pasta, carne, salsa y queso.");
        mapMenu.put("valor", 5000);

        Menu menu = new Menu();
        menu.setMenuID(menuID);
        menu.setNombre("Lasana");
        menu.setDescripcion("La lasana es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu.setValor(5000);
        menu.setActivo(true);

        when(repository.findById(menuID)).thenReturn(Optional.of(menu));
        when(repository.save(ArgumentMatchers.any(Menu.class))).thenReturn(menu);

        Menu result = service.editar(mapMenu, menuID);

        assertNotNull(result);
        assertEquals(menu.getMenuID(), result.getMenuID());
        assertEquals(menu.getNombre(), result.getNombre());
        assertEquals(menu.getDescripcion(), result.getDescripcion());
        assertEquals(menu.getValor(), result.getValor());
        assertEquals(menu.getActivo(), result.getActivo());
    }

    @Test
    void verMenu() {
        Long menuID = 1L;

        Menu menu = new Menu();
        menu.setMenuID(menuID);
        menu.setNombre("Lasana");
        menu.setDescripcion("La lasana es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu.setValor(5000);
        menu.setActivo(true);

        when(repository.findById(menuID)).thenReturn(Optional.of(menu));
        when(repository.save(ArgumentMatchers.any(Menu.class))).thenReturn(menu);

        Menu result = service.ver(menuID);

        assertNotNull(result);
        assertEquals(menu.getMenuID(), result.getMenuID());
        assertEquals(menu.getNombre(), result.getNombre());
        assertEquals(menu.getDescripcion(), result.getDescripcion());
        assertEquals(menu.getValor(), result.getValor());
        assertEquals(menu.getActivo(), result.getActivo());
    }

    @Test
    void cambiarEstadoMenu() {
        Long menuID = 1L;

        // Caso activar
        Menu menuInactivo = new Menu();
        menuInactivo.setMenuID(menuID);
        menuInactivo.setActivo(false);

        when(repository.findById(menuID)).thenReturn(Optional.of(menuInactivo));
        when(repository.save(ArgumentMatchers.any(Menu.class))).thenAnswer(invocation -> {
            Menu m = invocation.getArgument(0);
            m.setActivo(true);
            return m;
        });

        Menu resultadoActivar = service.activar(menuID);
        assertNotNull(resultadoActivar);
        assertTrue(resultadoActivar.getActivo());
        assertEquals(menuID, resultadoActivar.getMenuID());

        // Caso desactivar
        Menu menuActivo = new Menu();
        menuActivo.setMenuID(menuID);
        menuActivo.setActivo(true);

        when(repository.findById(menuID)).thenReturn(Optional.of(menuActivo));
        when(repository.save(ArgumentMatchers.any(Menu.class))).thenAnswer(invocation -> {
            Menu m = invocation.getArgument(0);
            m.setActivo(false);
            return m;
        });

        Menu resultadoDesactivar = service.desactivar(menuID);
        assertNotNull(resultadoDesactivar);
        assertFalse(resultadoDesactivar.getActivo());
        assertEquals(menuID, resultadoDesactivar.getMenuID());
    }

    @Test
    void listaMenu() {
        List<Menu> menus = new ArrayList<>();

        Menu menu1 = new Menu();
        menu1.setMenuID(1L);
        menu1.setNombre("Lasana");
        menu1.setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu1.setValor(5000);
        menu1.setActivo(true);

        Menu menu2 = new Menu();
        menu2.setMenuID(2L);
        menu2.setNombre("Pizza");
        menu2.setDescripcion("Pizza con queso y pepperoni.");
        menu2.setValor(7000);
        menu2.setActivo(true);

        menus.add(menu1);
        menus.add(menu2);

        when(repository.findAll()).thenReturn(menus);

        List<Menu> result = service.listaMenus();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(menu1.getMenuID(), result.get(0).getMenuID());
        assertEquals(menu2.getMenuID(), result.get(1).getMenuID());
    }

    @Test
    void listaActivosMenu() {
        List<Menu> activeMenus = new ArrayList<>();

        Menu menu1 = new Menu();
        menu1.setMenuID(1L);
        menu1.setNombre("Lasana");
        menu1.setDescripcion("La lasaña es un plato italiano con capas de pasta, carne, salsa y queso.");
        menu1.setValor(5000);
        menu1.setActivo(true);

        Menu menu2 = new Menu();
        menu2.setMenuID(2L);
        menu2.setNombre("Pizza");
        menu2.setDescripcion("Pizza con queso y pepperoni.");
        menu2.setValor(7000);
        menu2.setActivo(true);

        activeMenus.add(menu1);
        activeMenus.add(menu2);

        when(repository.findAllByActivoTrue()).thenReturn(activeMenus);

        List<Menu> result = service.listaMenusActivos();

        assertNotNull(result);
        assertEquals(2, result.size());
        assertTrue(result.stream().allMatch(Menu::getActivo));
        assertEquals(menu1.getMenuID(), result.get(0).getMenuID());
        assertEquals(menu2.getMenuID(), result.get(1).getMenuID());
    }
}
