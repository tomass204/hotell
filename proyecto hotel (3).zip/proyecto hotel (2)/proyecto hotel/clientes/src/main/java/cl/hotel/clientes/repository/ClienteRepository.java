package cl.hotel.clientes.repository;

import cl.hotel.clientes.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository //para que el ClienteRepository se pa que sera el repositorio
public interface ClienteRepository extends JpaRepository<Cliente,Long> {
    //aqui estamos heredando de Jparepository, que es una interfaz de Spring Data JPA,
    //hace que el repositorio tenga los metodos de CRUD

    Optional<Cliente> findByRun(String run);
    //Estos metodos Optional sirve para hacer login o validacion de acceso osea busca un cliente por su run o contrasena
    //o ver si esta activo

    Optional<Cliente> findByRunAndContrasenaAndActivoTrue(String run, String contrasena);

   Optional<Cliente> findByRunAndActivoTrue(String run);

    List<Cliente> findByRol(String rol);
    Optional<Cliente> findFirstByRol(String rol);




}
