package cl.hotel.clientes.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import io.swagger.v3.oas.annotations.media.Schema; // 🔁 Agregado para Swagger

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity //marca la clase como un entidad JPA
@Table(name = "clientes") //Define el nombre que tendrá en la base de datos
@Data // genera getters, setters, @ToString() y más
@AllArgsConstructor // genera un constructor con todos los campos
@NoArgsConstructor  // genera un constructor vacío
@Schema(description = "Entidad que representa a un cliente del hotel") // 🔁 Descripción general
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cliente_id")
    @Schema(description = "ID único del cliente", example = "1")
    private Long clienteID; //se genera automáticamente

    @Column(nullable = false)
    @Schema(description = "RUN del cliente", example = "12345678-9", required = true)
    private String run;

    @Column(nullable = false)
    @Schema(description = "Nombres del cliente", example = "Juan Carlos", required = true)
    private String nombres;

    @Column(nullable = false)
    @Schema(description = "Apellidos del cliente", example = "Pérez Soto", required = true)
    private String apellidos;

    @Column(nullable = false)
    @Schema(description = "Teléfono del cliente", example = "+56912345678", required = true)
    private String telefono;

    @Column(nullable = false)
    @Schema(description = "Correo electrónico del cliente", example = "juan@mail.com", required = true)
    private String email;

    @Column(nullable = false)
    @Schema(description = "Rol del cliente en el sistema", example = "cliente", required = true)
    private String rol;

    @Column(nullable = false)
    @JsonIgnore
    @Schema(description = "Contraseña del cliente (oculta en respuestas)", example = "1234", required = true, accessMode = Schema.AccessMode.WRITE_ONLY)
    private String contrasena;

    @Column(nullable = false)
    @Schema(description = "Indica si el cliente está activo", example = "true", required = true)
    private Boolean activo;
}

