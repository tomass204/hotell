package cl.hotel.clientes.service;


import cl.hotel.clientes.model.Cliente;
import cl.hotel.clientes.repository.ClienteRepository;
import cl.hotel.clientes.security.authentication.PasswordManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class ClienteService {

    @Autowired
    private ClienteRepository repository;

    @Autowired
    private PasswordManager passwordManager;

    public Cliente iniciarSession(String run, String contrasena){
        //
        Optional<Cliente> clienteOptional = repository.findByRunAndActivoTrue(run);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("Error al iniciar session.");
        }

        Cliente cliente=clienteOptional.get();



        if(!passwordManager.verificarPassword(contrasena, cliente.getContrasena())){
            throw new RuntimeException("Error al iniciar session.");

        }

        return repository.save(cliente);
    }


    public Cliente crear(Map<String, Object> map_cliente) {
        String run = String.valueOf(map_cliente.get("run"));
        // Check if client with same RUN already exists
        if (repository.findByRun(run).isPresent()) {
            throw new RuntimeException("Cliente con RUN " + run + " ya existe.");
        }
        Cliente cliente = new Cliente();
        cliente.setRun(run);
        cliente.setNombres(String.valueOf(map_cliente.get("nombres")));
        cliente.setApellidos(String.valueOf(map_cliente.get("apellidos")));
        cliente.setEmail(String.valueOf(map_cliente.get("email")));
        cliente.setTelefono(String.valueOf(map_cliente.get("telefono")));
        cliente.setRol(String.valueOf(map_cliente.get("rol")) );
        String contrasena=String.valueOf(map_cliente.get("contrasena"));
        cliente.setContrasena(passwordManager.encriptarPassword(contrasena));
        cliente.setClienteID(null);
        cliente.setActivo(true);
        return repository.save(cliente);
    }

    public Cliente editar(Map<String, Object> map_cliente, Long clienteID) {
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe la habitación.");
        }
        Cliente cliente = clienteOptional.get();
        cliente.setRun(String.valueOf(map_cliente.get("run")));
        cliente.setNombres(String.valueOf(map_cliente.get("nombres")));
        cliente.setApellidos(String.valueOf(map_cliente.get("apellidos")));
        cliente.setEmail(String.valueOf(map_cliente.get("email")));
        cliente.setTelefono(String.valueOf(map_cliente.get("telefono")));
        cliente.setRol(String.valueOf(map_cliente.get("rol")) );
        String contrasena=String.valueOf(map_cliente.get("contrasena"));
        cliente.setContrasena(passwordManager.encriptarPassword(contrasena));
        return repository.save(cliente);
    }

    public Cliente ver(Long clienteID) {
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        return repository.save(clienteOptional.get());
    }

    public Cliente verPorRun(String run) {
        Optional<Cliente> clienteOptional = repository.findByRun(run);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        return repository.save(clienteOptional.get());
    }






    
    public Cliente activar(Long clienteID) {
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        Cliente cliente = clienteOptional.get();
        cliente.setActivo(true);
        return repository.save(cliente);
    }

    public Cliente desactivar(Long clienteID) {
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        Cliente cliente = clienteOptional.get();
        cliente.setActivo(false);
        return repository.save(cliente);
    }
    
    public Cliente buscarPorRol(String rol) {
    return repository.findFirstByRol(rol)
        .orElseThrow(() -> new RuntimeException("No se encontró cliente con el rol: " + rol));
    }

    public List<Cliente> listarPorRol(String rol) {
    return repository.findByRol(rol);
    }



}
