package cl.hotel.clientes.controller;


import cl.hotel.clientes.model.Cliente;
import cl.hotel.clientes.service.ClienteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.Map;

@RestController //Marca la clase como un controlador
@RequestMapping("/api/hotel/v1/clientes") //Define la ruta base de la API
public class ClienteController {

    @Autowired
    private ClienteService service;

    @Operation(summary = "Permite iniciar sesión de un cliente con RUN y contraseña")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Autentica al cliente y devuelve sus datos si las credenciales son correctas",
            content = @Content(schema = @Schema(implementation = Cliente.class))
        ),
        @ApiResponse(
            responseCode = "401",
            description = "Error iniciar sesión, credenciales incorrectas"
        )
    })
    @PostMapping("/iniciar-session")
    public EntityModel<Cliente> iniciarSession(@RequestParam(name = "run", required = true) String run,
                                               @RequestParam(name = "contrasena", required = true) String contrasena) {
        Cliente cliente = service.iniciarSession(run, contrasena);

        EntityModel<Cliente> recurso = EntityModel.of(cliente,
            linkTo(methodOn(ClienteController.class).ver(cliente.getClienteID())).withSelfRel(),
            linkTo(methodOn(ClienteController.class).editar(null, cliente.getClienteID())).withRel("editar"),
            linkTo(methodOn(ClienteController.class).cambiarEstado(cliente.getClienteID(), !cliente.getActivo())).withRel(cliente.getActivo() ? "desactivar" : "activar")
        );

        return recurso;
    }

    @Operation(summary = "Permite crear un cliente con sus datos")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Recibe un Map<String, Object> que representa las características del cliente y crea un nuevo cliente",
            content = @Content(schema = @Schema(implementation = Cliente.class))
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Datos inválidos para crear el cliente"
        )
    })
    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Map<String, Object> cliente) {
        try {
            Cliente nuevo = service.crear(cliente);

            EntityModel<Cliente> recurso = EntityModel.of(nuevo,
                linkTo(methodOn(ClienteController.class).ver(nuevo.getClienteID())).withSelfRel(),
                linkTo(methodOn(ClienteController.class).editar(null, nuevo.getClienteID())).withRel("editar"),
                linkTo(methodOn(ClienteController.class).cambiarEstado(nuevo.getClienteID(), !nuevo.getActivo())).withRel(nuevo.getActivo() ? "desactivar" : "activar")
            );

            return ResponseEntity.ok(recurso);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @Operation(summary = "Permite editar un cliente existente con sus datos actualizados")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Recibe un Map<String, Object> con los nuevos datos para actualizar un cliente existente",
            content = @Content(schema = @Schema(implementation = Cliente.class))
        ),
        @ApiResponse(
            responseCode = "400",
            description = "Datos inválidos para actualizar el cliente"
        )
    })
    @PutMapping("/{clienteID}")
    public EntityModel<Cliente> editar(@RequestBody Map<String, Object> cliente, @PathVariable Long clienteID) {
        Cliente actualizado = service.editar(cliente, clienteID);

        EntityModel<Cliente> recurso = EntityModel.of(actualizado,
            linkTo(methodOn(ClienteController.class).ver(clienteID)).withSelfRel(),
            linkTo(methodOn(ClienteController.class).cambiarEstado(clienteID, !actualizado.getActivo())).withRel(actualizado.getActivo() ? "desactivar" : "activar")
        );

        return recurso;
    }

    @Operation(summary = "Permite cambiar el estado (activar/desactivar) de un cliente existente en el sistema")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Modifica parcialmente un cliente para cambiar su estado",
            content = @Content(schema = @Schema(implementation = Cliente.class))
        ),
        @ApiResponse(
            responseCode = "400",
            description = "ID inválido o el cliente no puede ser actualizado"
        )
    })
    @PatchMapping("/cambiar-estado/{clienteID}")
    public EntityModel<Cliente> cambiarEstado(@PathVariable Long clienteID, @RequestParam boolean activar) {
        Cliente cliente = activar ? service.activar(clienteID) : service.desactivar(clienteID);

        EntityModel<Cliente> recurso = EntityModel.of(cliente,
            linkTo(methodOn(ClienteController.class).ver(clienteID)).withSelfRel(),
            linkTo(methodOn(ClienteController.class).editar(null, clienteID)).withRel("editar"),
            linkTo(methodOn(ClienteController.class).cambiarEstado(clienteID, !activar)).withRel(activar ? "desactivar" : "activar")
        );

        return recurso;
    }

    @Operation(summary = "Permite obtener un cliente existente por su ID")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Devuelve los detalles completos de un cliente dado su ID",
            content = @Content(schema = @Schema(implementation = Cliente.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Cliente no encontrado con el ID proporcionado"
        )
    })
    @GetMapping("/{clienteID}")
    public EntityModel<Cliente> ver(@PathVariable Long clienteID) {
        Cliente cliente = service.ver(clienteID);

        EntityModel<Cliente> recurso = EntityModel.of(cliente,
            linkTo(methodOn(ClienteController.class).editar(null, clienteID)).withRel("editar"),
            linkTo(methodOn(ClienteController.class).cambiarEstado(clienteID, !cliente.getActivo())).withRel(cliente.getActivo() ? "desactivar" : "activar"),
            linkTo(methodOn(ClienteController.class).ver(clienteID)).withSelfRel()
        );

        return recurso;
    }

    @Operation(summary = "Permite obtener un cliente existente por su RUN")
    @ApiResponses(value = {
        @ApiResponse(
            responseCode = "200",
            description = "Devuelve los detalles completos de un cliente dado su RUN",
            content = @Content(schema = @Schema(implementation = Cliente.class))
        ),
        @ApiResponse(
            responseCode = "404",
            description = "Cliente no encontrado con el RUN proporcionado"
        )
    })
    @GetMapping("/run/{run}")
    public EntityModel<Cliente> verPorRun(@PathVariable String run) {
        Cliente cliente = service.verPorRun(run);

        EntityModel<Cliente> recurso = EntityModel.of(cliente,
            linkTo(methodOn(ClienteController.class).editar(null, cliente.getClienteID())).withRel("editar"),
            linkTo(methodOn(ClienteController.class).cambiarEstado(cliente.getClienteID(), !cliente.getActivo())).withRel(cliente.getActivo() ? "desactivar" : "activar"),
            linkTo(methodOn(ClienteController.class).ver(cliente.getClienteID())).withRel("self")
        );

        return recurso;
    }

    @Operation(summary = "Busca un cliente por su rol")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Cliente encontrado", content = @Content(schema = @Schema(implementation = Cliente.class))),
        @ApiResponse(responseCode = "404", description = "Cliente no encontrado")
    })
    @GetMapping("/buscar-por-rol/{rol}")
    public ResponseEntity<EntityModel<Cliente>> buscarPorRol(@PathVariable String rol) {
        Cliente cliente = service.buscarPorRol(rol);  
        EntityModel<Cliente> recurso = EntityModel.of(cliente,
            linkTo(methodOn(ClienteController.class).ver(cliente.getClienteID())).withRel("ver"),
            linkTo(methodOn(ClienteController.class).editar(null, cliente.getClienteID())).withRel("editar"),
            linkTo(methodOn(ClienteController.class).cambiarEstado(cliente.getClienteID(), true)).withRel("activar"),
            linkTo(methodOn(ClienteController.class).cambiarEstado(cliente.getClienteID(), false)).withRel("desactivar"),
            linkTo(methodOn(ClienteController.class).listarPorRol(rol)).withSelfRel()
        );
        return ResponseEntity.ok(recurso);
    }

    @Operation(summary = "Lista todos los clientes por rol")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Lista de clientes", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Cliente.class))))
    })
    @GetMapping("/listar-por-rol/{rol}")
    public ResponseEntity<CollectionModel<EntityModel<Cliente>>> listarPorRol(@PathVariable String rol) {
        List<Cliente> clientes = service.listarPorRol(rol);
        List<EntityModel<Cliente>> recursos = clientes.stream()
            .map(cliente -> EntityModel.of(cliente,
                linkTo(methodOn(ClienteController.class).ver(cliente.getClienteID())).withRel("ver"),
                linkTo(methodOn(ClienteController.class).editar(null, cliente.getClienteID())).withRel("editar"),
                linkTo(methodOn(ClienteController.class).cambiarEstado(cliente.getClienteID(), true)).withRel("activar"),
                linkTo(methodOn(ClienteController.class).cambiarEstado(cliente.getClienteID(), false)).withRel("desactivar")
            ))
            .toList();

        CollectionModel<EntityModel<Cliente>> collection = CollectionModel.of(recursos,
            linkTo(methodOn(ClienteController.class).buscarPorRol(rol)).withSelfRel()
        );

        return ResponseEntity.ok(collection);
    }
}



