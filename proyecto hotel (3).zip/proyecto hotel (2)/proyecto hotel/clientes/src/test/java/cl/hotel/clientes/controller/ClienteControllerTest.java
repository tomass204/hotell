package cl.hotel.clientes.controller;

import cl.hotel.clientes.model.Cliente;
import cl.hotel.clientes.service.ClienteService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.anyString;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(ClienteController.class)
class ClienteControllerTest {

    @MockBean
    private ClienteService service;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void iniciarSession() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("John");
        cliente.setApellidos("Doe");
        cliente.setTelefono("123456789");
        cliente.setEmail("john@example.com");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(service.iniciarSession(eq("12345678-9"), eq("password"))).thenReturn(cliente);

        try {
            mockMvc.perform(post("/api/hotel/v1/clientes/iniciar-session")
                    .param("run", "12345678-9")
                    .param("contrasena", "password"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.clienteID").value(1L))
                .andExpect(jsonPath("$.run").value("12345678-9"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void crearCliente() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("John");
        cliente.setApellidos("Doe");
        cliente.setTelefono("123456789");
        cliente.setEmail("john@example.com");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(service.crear(anyMap())).thenReturn(cliente);

        String json = "{\n" +
                "  \"run\": \"12345678-9\",\n" +
                "  \"nombres\": \"John\",\n" +
                "  \"apellidos\": \"Doe\",\n" +
                "  \"contrasena\": \"password\"\n" +
                "}";

        try {
            mockMvc.perform(post("/api/hotel/v1/clientes")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.clienteID").value(1L))
                .andExpect(jsonPath("$.run").value("12345678-9"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void editarCliente() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("John");
        cliente.setApellidos("Doe");
        cliente.setTelefono("123456789");
        cliente.setEmail("john@example.com");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(service.editar(anyMap(), eq(1L))).thenReturn(cliente);

        String json = "{\n" +
                "  \"nombres\": \"John\",\n" +
                "  \"apellidos\": \"Doe\",\n" +
                "  \"contrasena\": \"newpassword\"\n" +
                "}";

        try {
            mockMvc.perform(put("/api/hotel/v1/clientes/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.clienteID").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void activarCliente() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("John");
        cliente.setApellidos("Doe");
        cliente.setTelefono("123456789");
        cliente.setEmail("john@example.com");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(service.activar(1L)).thenReturn(cliente);

        try {
            mockMvc.perform(patch("/api/hotel/v1/clientes/cambiar-estado/1")
                    .param("activar", "true")
                    .contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activo").value(true));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void desactivarCliente() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("John");
        cliente.setApellidos("Doe");
        cliente.setTelefono("123456789");
        cliente.setEmail("john@example.com");
        cliente.setContrasena("password");
        cliente.setActivo(false);

        when(service.desactivar(1L)).thenReturn(cliente);

        try {
            mockMvc.perform(patch("/api/hotel/v1/clientes/cambiar-estado/1")
                    .param("activar", "false")
                    .contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activo").value(false));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void verCliente() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("John");
        cliente.setApellidos("Doe");
        cliente.setTelefono("123456789");
        cliente.setEmail("john@example.com");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(service.ver(1L)).thenReturn(cliente);

        try {
            mockMvc.perform(get("/api/hotel/v1/clientes/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.clienteID").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void verClientePorRun() throws Exception {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("John");
        cliente.setApellidos("Doe");
        cliente.setTelefono("123456789");
        cliente.setEmail("john@example.com");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(service.verPorRun("12345678-9")).thenReturn(cliente);

        try {
            mockMvc.perform(get("/api/hotel/v1/clientes/run/12345678-9"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.clienteID").value(1L));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
