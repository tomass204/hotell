package cl.hotel.clientes.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;

import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import cl.hotel.clientes.model.Cliente;
import cl.hotel.clientes.repository.ClienteRepository;

@ExtendWith(MockitoExtension.class)
public class ClienteServiceTest {
    @Mock
    private ClienteRepository repository;

    @Mock
    private cl.hotel.clientes.security.authentication.PasswordManager passwordManager;

    @InjectMocks
    private ClienteService service;

    @Test
    void IniciarSesionCliente() {
        String run = "12345678-9";
        String contrasena = "password";

        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun(run);
        cliente.setContrasena("encryptedPassword");
        cliente.setActivo(true);

        when(repository.findByRunAndActivoTrue(run)).thenReturn(Optional.of(cliente));
        when(passwordManager.verificarPassword(contrasena, "encryptedPassword")).thenReturn(true);
        when(repository.save(cliente)).thenReturn(cliente);

        Cliente result = service.iniciarSession(run, contrasena);

        assertNotNull(result);
        assertEquals(cliente.getClienteID(), result.getClienteID());
        assertEquals(cliente.getRun(), result.getRun());
        assertEquals(cliente.getContrasena(), result.getContrasena());
        assertEquals(cliente.getActivo(), result.getActivo());
    }

    @Test
    void crearCliente() {
        Map<String, Object> mapCliente = new HashMap<>();
        mapCliente.put("run", "12345678-9");
        mapCliente.put("nombres", "Juan");
        mapCliente.put("apellidos", "Perez");
        mapCliente.put("email", "juan.perez@example.com");
        mapCliente.put("telefono", "123456789");
        mapCliente.put("contrasena", "password");

        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("Juan");
        cliente.setApellidos("Perez");
        cliente.setEmail("juan.perez@example.com");
        cliente.setTelefono("123456789");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(passwordManager.encriptarPassword("password")).thenReturn("password");
        when(repository.save(ArgumentMatchers.any(Cliente.class))).thenReturn(cliente);

        Cliente result = service.crear(mapCliente);

        assertNotNull(result);
        assertEquals(cliente.getClienteID(), result.getClienteID());
        assertEquals(cliente.getRun(), result.getRun());
        assertEquals(cliente.getNombres(), result.getNombres());
        assertEquals(cliente.getApellidos(), result.getApellidos());
        assertEquals(cliente.getEmail(), result.getEmail());
        assertEquals(cliente.getTelefono(), result.getTelefono());
        assertEquals(cliente.getContrasena(), result.getContrasena());
        assertEquals(cliente.getActivo(), result.getActivo());
    }

    @Test
    void editarCliente() {
        Map<String, Object> mapCliente = new HashMap<>();
        mapCliente.put("run", "12345678-9");
        mapCliente.put("nombres", "Juan");
        mapCliente.put("apellidos", "Perez");
        mapCliente.put("email", "juan.perez@example.com");
        mapCliente.put("telefono", "123456789");
        mapCliente.put("contrasena", "password");

        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("Juan");
        cliente.setApellidos("Perez");
        cliente.setEmail("juan.perez@example.com");
        cliente.setTelefono("123456789");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(passwordManager.encriptarPassword("password")).thenReturn("password");
        when(repository.findById(1L)).thenReturn(Optional.of(cliente));
        when(repository.save(ArgumentMatchers.any(Cliente.class))).thenReturn(cliente);

        Cliente result = service.editar(mapCliente, 1L);

        assertNotNull(result);
        assertEquals(cliente.getClienteID(), result.getClienteID());
        assertEquals(cliente.getRun(), result.getRun());
        assertEquals(cliente.getNombres(), result.getNombres());
        assertEquals(cliente.getApellidos(), result.getApellidos());
        assertEquals(cliente.getEmail(), result.getEmail());
        assertEquals(cliente.getTelefono(), result.getTelefono());
        assertEquals(cliente.getContrasena(), result.getContrasena());
        assertEquals(cliente.getActivo(), result.getActivo());
    }

    @Test
    void verCliente() {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setRun("12345678-9");
        cliente.setNombres("Juan");
        cliente.setApellidos("Perez");
        cliente.setEmail("juan.perez@example.com");
        cliente.setTelefono("123456789");
        cliente.setContrasena("password");
        cliente.setActivo(true);

        when(repository.findById(1L)).thenReturn(Optional.of(cliente));
        when(repository.save(ArgumentMatchers.any(Cliente.class))).thenReturn(cliente);

        Cliente result = service.ver(1L);

        assertNotNull(result);
        assertEquals(cliente.getClienteID(), result.getClienteID());
        assertEquals(cliente.getRun(), result.getRun());
        assertEquals(cliente.getNombres(), result.getNombres());
        assertEquals(cliente.getApellidos(), result.getApellidos());
        assertEquals(cliente.getEmail(), result.getEmail());
        assertEquals(cliente.getTelefono(), result.getTelefono());
        assertEquals(cliente.getContrasena(), result.getContrasena());
        assertEquals(cliente.getActivo(), result.getActivo());
    }

    @Test
    void verPorRunCliente() {
        String run = "00000000-0";

        when(repository.findByRun(run)).thenReturn(Optional.empty());

        org.junit.jupiter.api.Assertions.assertThrows(RuntimeException.class, () -> {
            service.verPorRun(run);
        });
    }

    @Test
    void activarCliente() {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setActivo(true);

        when(repository.findById(1L)).thenReturn(Optional.of(cliente));
        when(repository.save(ArgumentMatchers.any(Cliente.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Cliente result = service.activar(1L);

        assertNotNull(result);
        assertEquals(1L, result.getClienteID());
        assertTrue(result.getActivo());
    }

    @Test
    void desactivarCliente() {
        Cliente cliente = new Cliente();
        cliente.setClienteID(1L);
        cliente.setActivo(false);

        when(repository.findById(1L)).thenReturn(Optional.of(cliente));
        when(repository.save(ArgumentMatchers.any(Cliente.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Cliente result = service.desactivar(1L);

        assertNotNull(result);
        assertEquals(1L, result.getClienteID());
        assertTrue(!result.getActivo());
    }
}
