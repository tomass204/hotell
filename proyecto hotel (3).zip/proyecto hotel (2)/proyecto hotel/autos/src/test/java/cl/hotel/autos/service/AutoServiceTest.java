package cl.hotel.autos.service;

import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import static org.assertj.core.api.Assertions.assertThat;
import cl.hotel.autos.model.Auto;
import cl.hotel.autos.repository.AutoRepository;

@ExtendWith(MockitoExtension.class)
public class AutoServiceTest {
        @Mock
        private AutoRepository repository;

        @InjectMocks
        private AutoService service;

        @Test
        void listaAutos(){
            List<Auto> mockList = Arrays.asList(new Auto(1L, "Auto", "Mercedez", "accent", "con asientos malos", 3000, null));

            when(repository.findAll()).thenReturn(mockList);

            List<Auto> result = service.listaAutos();

            assertThat(result).isEqualTo(mockList);
        }

        @Test
        void editarAuto(){
            Auto auto = new Auto(1L, "Auto", "Mercedez", "accent", "con asientos malos", 3000, null);
            Map<String, Object> mapAuto = Map.of(
                "tipo", auto.getTipo(),
                "marca", auto.getMarca(),
                "modelo", auto.getModelo(),
                "descripcion", auto.getDescripcion(),
                "valor", auto.getValor()
            );

            when(repository.findById(1L)).thenReturn(Optional.of(auto));
            when(repository.save(auto)).thenReturn(auto);

            Auto result = service.editar(mapAuto, 1L);

            assertThat(result).isEqualTo(auto);
        }

        @Test
        void verAuto(){
            Auto auto = new Auto(1L, "Auto", "Mercedez", "accent", "con asientos malos", 3000, null);
            when(repository.findById(1L)).thenReturn(Optional.of(auto));
            when(repository.save(auto)).thenReturn(auto);
            Auto result = service.ver(1L);
            assertThat(result).isEqualTo(auto);
        }

        @Test
        void activarAuto(){
            Auto auto = new Auto(1L,"Auto","Mercedez","accent","con asientos malos",3000,null);
            when(repository.findById(1L)).thenReturn(Optional.of(auto));
            when(repository.save(auto)).thenReturn(auto);
            Auto result = service.activar(1L);
            auto.setActivo(true);
            assertThat(result).isEqualTo(auto);
        }

        @Test
        void desactivarAuto(){
            Auto auto = new Auto(1L, "Auto", "Mercedecez", "accent", "con asientos malos", 300, null);
            when(repository.findById(1L)).thenReturn(Optional.of(auto));
            when(repository.save(auto)).thenReturn(auto);
            Auto result = service.desactivar(1L);
            auto.setActivo(false);
            assertThat(result).isEqualTo(auto);
        }
        

    @Test
    void listarAutosActivos(){
        List<Auto> mockList = Arrays.asList(new Auto(1L, "Auto", "Mercedez", "accent", "con asientos buenos", 3000, null));

        when(repository.findAllByActivoTrue()).thenReturn(mockList);

        List<Auto> result = service.listaAutosActivos();

        assertThat(result).isEqualTo(mockList);
    }
}   

