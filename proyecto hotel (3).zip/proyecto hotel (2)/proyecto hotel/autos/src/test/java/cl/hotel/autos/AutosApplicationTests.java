package cl.hotel.autos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
