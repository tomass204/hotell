package cl.hotel.autos.controller;

import cl.hotel.autos.controller.AutoController;
import cl.hotel.autos.service.AutoService;
import cl.hotel.autos.model.Auto;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AutoController.class)
class AutoControlladorTest {

    @MockBean
    private AutoService service;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void listarAutos() throws Exception {
        List<Auto> autos = List.of(new Auto(1L, "Auto", "Mercedez", "Accent", "Buen estado", 3000, true));

        when(service.listaAutos()).thenReturn(autos);

        mockMvc.perform(get("/api/hotel/v1/autos/listar"))
                .andDo(result -> System.out.println("Response: " + result.getResponse().getContentAsString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.autoList[0].autoID").value(1))
                .andExpect(jsonPath("$._embedded.autoList[0].marca").value("Mercedez"));
    }

    @Test
    void verAuto() throws Exception {
        Auto auto = new Auto(1L, "Auto", "Mercedez", "Accent", "Buen estado", 3000, true);

        when(service.ver(1L)).thenReturn(auto);

        mockMvc.perform(get("/api/hotel/v1/autos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.autoID").value(1))
                .andExpect(jsonPath("$.modelo").value("Accent"));
    }

    @Test
    void activarAuto() throws Exception {
        Auto auto = new Auto(1L, "Auto", "Mercedez", "Accent", "Buen estado", 3000, true);

        when(service.activar(1L)).thenReturn(auto);

        mockMvc.perform(patch("/api/hotel/v1/autos/cambiar-estado/1?activar=true"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activo").value(true));
    }

    @Test
    void desactivarAuto() throws Exception {
        Auto auto = new Auto(1L, "Auto", "Mercedez", "Accent", "Buen estado", 3000, false);

        when(service.desactivar(1L)).thenReturn(auto);

        mockMvc.perform(patch("/api/hotel/v1/autos/cambiar-estado/1?activar=false"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activo").value(false));
    }

    @Test
    void listarAutosActivos() throws Exception {
        List<Auto> autos = List.of(new Auto(1L, "Auto", "Mercedez", "Accent", "Buen estado", 3000, true));

        when(service.listaAutosActivos()).thenReturn(autos);

        mockMvc.perform(get("/api/hotel/v1/autos/listar-activos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.autoList[0].activo").value(true));
    }

    @Test
    void editarAuto() throws Exception {
        Auto auto = new Auto(1L, "Auto", "Mercedez", "Accent", "Editado", 3000, true);

        when(service.editar(anyMap(), eq(1L))).thenReturn(auto);

        String json = "{\n" +
                "  \"tipo\": \"Auto\",\n" +
                "  \"marca\": \"Mercedez\",\n" +
                "  \"modelo\": \"Accent\",\n" +
                "  \"descripcion\": \"Editado\",\n" +
                "  \"valor\": 3000\n" +
                "}";

        mockMvc.perform(put("/api/hotel/v1/autos/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.descripcion").value("Editado"));
    }
}
