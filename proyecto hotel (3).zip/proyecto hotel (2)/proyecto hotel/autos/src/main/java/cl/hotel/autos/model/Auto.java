package cl.hotel.autos.model;

import io.swagger.v3.oas.annotations.media.Schema; // 🔁 Importación para Swagger

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "autos")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa un auto disponible en el hotel")
public class Auto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "auto_id")
    @Schema(description = "ID único del auto", example = "1")
    private Long autoID;

    @Column(nullable = false)
    @Schema(description = "Tipo de auto", example = "SUV", required = true)
    private String tipo;

    @Column(nullable = false)
    @Schema(description = "Marca del auto", example = "Toyota", required = true)
    private String marca;

    @Column(nullable = false)
    @Schema(description = "Modelo del auto", example = "RAV4", required = true)
    private String modelo;

    @Column(nullable = false)
    @Schema(description = "Descripción del auto", example = "SUV familiar de 5 puertas", required = true)
    private String descripcion;

    @Column(nullable = false)
    @Schema(description = "Valor del auto en pesos", example = "35000", required = true)
    private Integer valor;

    @Column(nullable = false)
    @Schema(description = "Indica si el auto está activo", example = "true", required = true)
    private Boolean activo;
}
