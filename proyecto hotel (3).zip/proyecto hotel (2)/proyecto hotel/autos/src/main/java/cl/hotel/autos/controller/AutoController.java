package cl.hotel.autos.controller;

import cl.hotel.autos.model.Auto;
import cl.hotel.autos.service.AutoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.stream.Collectors;

import java.util.List;
import java.util.Map;


@RestController
@RequestMapping("/api/hotel/v1/autos")
public class AutoController {

    @Autowired
    private AutoService service;

    @Operation(summary = "Permite crear un auto con sus cualidades")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Recibe un Map<String, Object> que representa las características del auto", content = @Content(schema = @Schema(implementation = Auto.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Map<String, Object> auto) {
        try {
            Auto creado = service.crear(auto);

            EntityModel<Auto> recurso = EntityModel.of(creado,
                linkTo(methodOn(AutoController.class).ver(creado.getAutoID())).withSelfRel(),
                linkTo(methodOn(AutoController.class).editar(null, creado.getAutoID())).withRel("editar"),
                linkTo(methodOn(AutoController.class).listaAutos()).withRel("todos"),
                linkTo(methodOn(AutoController.class).cambiarEstado(creado.getAutoID(), !creado.getActivo())).withRel(creado.getActivo() ? "desactivar" : "activar")
            );

            return ResponseEntity.ok(recurso);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @Operation(summary = "Permite editar un auto con sus cualidades")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Permite editar un auto existente", content = @Content(schema = @Schema(implementation = Auto.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos")
    })
    @PutMapping("/{autoID}")
    public EntityModel<Auto> editar(@RequestBody Map<String, Object> auto, @PathVariable Long autoID) {
        Auto actualizado = service.editar(auto, autoID);

        EntityModel<Auto> recurso = EntityModel.of(actualizado,
            linkTo(methodOn(AutoController.class).ver(autoID)).withSelfRel(),
            linkTo(methodOn(AutoController.class).listaAutos()).withRel("todos"),
            linkTo(methodOn(AutoController.class).cambiarEstado(autoID, !actualizado.getActivo())).withRel(actualizado.getActivo() ? "desactivar" : "activar")
        );

        return recurso;
    }

    @Operation(summary = "Permite cambiar el estado (activar/desactivar) de un auto")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Modifica parcialmente un auto para cambiar su estado", content = @Content(schema = @Schema(implementation = Auto.class))),
        @ApiResponse(responseCode = "400", description = "ID inválido o el auto no puede ser actualizado")
    })
    @PatchMapping("/cambiar-estado/{autoID}")
    public EntityModel<Auto> cambiarEstado(@PathVariable Long autoID, @RequestParam boolean activar) {
        Auto auto = activar ? service.activar(autoID) : service.desactivar(autoID);

        EntityModel<Auto> recurso = EntityModel.of(auto,
            linkTo(methodOn(AutoController.class).ver(auto.getAutoID())).withSelfRel(),
            linkTo(methodOn(AutoController.class).editar(null, auto.getAutoID())).withRel("editar"),
            linkTo(methodOn(AutoController.class).listaAutos()).withRel("todos"),
            linkTo(methodOn(AutoController.class).cambiarEstado(auto.getAutoID(), !activar)).withRel(activar ? "desactivar" : "activar")
        );

        return recurso;
    }

    @Operation(summary = "Permite obtener un auto existente en el sistema")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve los detalles completos de un auto dado su ID", content = @Content(schema = @Schema(implementation = Auto.class))),
        @ApiResponse(responseCode = "404", description = "Auto no encontrado con el ID proporcionado")
    })
    @GetMapping("/{autoID}")
    public EntityModel<Auto> ver(@PathVariable Long autoID) {
        Auto auto = service.ver(autoID);

        EntityModel<Auto> recurso = EntityModel.of(auto,
            linkTo(methodOn(AutoController.class).ver(autoID)).withSelfRel(),
            linkTo(methodOn(AutoController.class).editar(null, autoID)).withRel("editar"),
            linkTo(methodOn(AutoController.class).listaAutos()).withRel("todos"),
            linkTo(methodOn(AutoController.class).cambiarEstado(autoID, !auto.getActivo())).withRel(auto.getActivo() ? "desactivar" : "activar")
        );

        return recurso;
    }

    @Operation(summary = "Permite obtener la lista de todos los autos disponibles")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve una lista con todos los autos registrados", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Auto.class))))
    })
    @GetMapping("/listar")
    public CollectionModel<EntityModel<Auto>> listaAutos() {
        List<Auto> autos = service.listaAutos();

        List<EntityModel<Auto>> autosConLinks = autos.stream().map(auto -> 
            EntityModel.of(auto,
                linkTo(methodOn(AutoController.class).ver(auto.getAutoID())).withSelfRel(),
                linkTo(methodOn(AutoController.class).editar(null, auto.getAutoID())).withRel("editar"),
                linkTo(methodOn(AutoController.class).cambiarEstado(auto.getAutoID(), true)).withRel("activar"),
                linkTo(methodOn(AutoController.class).cambiarEstado(auto.getAutoID(), false)).withRel("desactivar")
            )
        ).collect(Collectors.toList());

        return CollectionModel.of(autosConLinks,
            linkTo(methodOn(AutoController.class).listaAutos()).withSelfRel()
        );
    }

    @Operation(summary = "Permite obtener la lista de autos activos disponibles")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve una lista con todos los autos que están activos", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Auto.class))))
    })
    @GetMapping("/listar-activos")
    public CollectionModel<EntityModel<Auto>> listaAutosActivos() {
        List<Auto> autosActivos = service.listaAutosActivos();

        List<EntityModel<Auto>> autosConLinks = autosActivos.stream().map(auto -> 
            EntityModel.of(auto,
                linkTo(methodOn(AutoController.class).ver(auto.getAutoID())).withSelfRel(),
                linkTo(methodOn(AutoController.class).editar(null, auto.getAutoID())).withRel("editar"),
                linkTo(methodOn(AutoController.class).cambiarEstado(auto.getAutoID(), false)).withRel("desactivar")
            )
        ).collect(Collectors.toList());

        return CollectionModel.of(autosConLinks,
            linkTo(methodOn(AutoController.class).listaAutosActivos()).withSelfRel(),
            linkTo(methodOn(AutoController.class).listaAutos()).withRel("todos")
        );
    }
}