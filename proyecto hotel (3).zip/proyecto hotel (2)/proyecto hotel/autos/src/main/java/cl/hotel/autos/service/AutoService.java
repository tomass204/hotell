package cl.hotel.autos.service;

import cl.hotel.autos.model.Auto;
import cl.hotel.autos.repository.AutoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class AutoService {

    @Autowired
    private AutoRepository repository;

    public Auto crear (Map<String,Object> map_auto){
        String tipo = String.valueOf(map_auto.get("tipo"));
        String marca = String.valueOf(map_auto.get("marca"));
        String modelo = String.valueOf(map_auto.get("modelo"));
        // Check if auto with same tipo, marca, modelo exists
        if (repository.findByTipoAndMarcaAndModelo(tipo, marca, modelo).isPresent()) {
            throw new RuntimeException("Auto con tipo " + tipo + ", marca " + marca + " y modelo " + modelo + " ya existe.");
        }
        Auto auto= new Auto();
        auto.setTipo(tipo);
        auto.setMarca(marca);
        auto.setModelo(modelo);
        auto.setDescripcion(String.valueOf(map_auto.get("descripcion")));
        auto.setValor(Integer.valueOf(String.valueOf(map_auto.get("valor"))));
        auto.setAutoID(null);
        auto.setActivo(true);
        return repository.save(auto);
    }

    public Auto editar (Map<String,Object> map_auto, Long autoID){
        Optional<Auto> autoOptional=repository.findById(autoID);
        if(!autoOptional.isPresent()){
            throw new RuntimeException("No existe el auto.");
        }
        Auto auto= autoOptional.get();
        auto.setTipo(String.valueOf(map_auto.get("tipo")));
        auto.setMarca(String.valueOf(map_auto.get("marca")));
        auto.setModelo(String.valueOf(map_auto.get("modelo")));
        auto.setDescripcion(String.valueOf(map_auto.get("descripcion")));
        auto.setValor(Integer.valueOf(String.valueOf(map_auto.get("valor"))));
        return repository.save(auto);
    }

    public Auto ver (Long autoID){
        Optional<Auto> autoOptional=repository.findById(autoID);
        if(!autoOptional.isPresent()){
            throw new RuntimeException("No existe el auto.");
        }
        return repository.save(autoOptional.get());
    }

    public Auto activar (Long autoID){
        Optional<Auto> autoOptional=repository.findById(autoID);
        if(!autoOptional.isPresent()){
            throw new RuntimeException("No existe el auto.");
        }
        Auto auto=autoOptional.get();
        auto.setActivo(true);
        return repository.save(auto);
    }

    public Auto desactivar (Long autoID){
        Optional<Auto> autoOptional=repository.findById(autoID);
        if(!autoOptional.isPresent()){
            throw new RuntimeException("No existe el auto.");
        }
        Auto auto=autoOptional.get();
        auto.setActivo(false);
        return repository.save(auto);
    }



    //Devuelve una lista con todos los autos 
    public List<Auto> listaAutos(){
        return  repository.findAll();
    }


    //Devuelve solo los autos que están activos
    public List<Auto> listaAutosActivos(){
        return  repository.findAllByActivoTrue();
    }




}
