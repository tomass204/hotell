package cl.hotel.pagos.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import io.swagger.v3.oas.annotations.media.Schema;

@Entity
@Table(name = "pagos")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa un pago realizado en el sistema")
public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pago_id")
    @Schema(description = "Identificador único del pago", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long pagoID;

    @Column(name = "medio_pago", nullable = false)
    @Schema(description = "Medio de pago utilizado", example = "Tarjeta de crédito", required = true)
    private String medioPago;

    @Column(name = "total_pago", nullable = false)
    @Schema(description = "Monto total pagado", example = "150000", required = true)
    private Integer totalPago;

    @Column(nullable = false)
    @Schema(description = "Estado del pago: true si ya fue pagado, false si no", example = "true", required = true)
    private Boolean pagado;
}

