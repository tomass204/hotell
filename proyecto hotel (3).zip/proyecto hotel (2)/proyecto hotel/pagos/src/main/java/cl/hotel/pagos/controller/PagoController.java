package cl.hotel.pagos.controller;

import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import cl.hotel.pagos.model.Pago;
import cl.hotel.pagos.service.PagoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/pagos")
public class PagoController {

    @Autowired
    private PagoService service;

//crea un pago con sus componentes

@Operation(summary = "Permite crear un pago con sus detalles")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Recibe un Map<String, Object> que representa los datos del pago y registra un nuevo pago",
        content = @Content(schema = @Schema(implementation = Pago.class))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "Datos inválidos para crear el pago"
    )
})

@PostMapping
public ResponseEntity<EntityModel<Pago>> crear(@RequestBody Map<String, Object> pago) {
    Pago nuevo = service.crear(pago);
    EntityModel<Pago> recurso = EntityModel.of(nuevo);
    recurso.add(linkTo(methodOn(PagoController.class).ver(nuevo.getPagoID())).withSelfRel());
    recurso.add(linkTo(methodOn(PagoController.class).editar(null, nuevo.getPagoID())).withRel("editar"));
    recurso.add(linkTo(methodOn(PagoController.class).pagar(nuevo.getPagoID())).withRel("pagar"));
    return ResponseEntity.ok(recurso);
}




    //Edita un pago

@Operation(summary = "Permite editar un pago existente")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Recibe un Map<String, Object> con los datos actualizados y modifica el pago identificado por su ID",
        content = @Content(schema = @Schema(implementation = Pago.class))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "Datos inválidos para actualizar el pago"
    ),
    @ApiResponse(
        responseCode = "404",
        description = "Pago no encontrado con el ID proporcionado"
    )
})

@PutMapping("/{pagoID}")
public ResponseEntity<EntityModel<Pago>> editar(@RequestBody Map<String, Object> pago, @PathVariable Long pagoID) {
    Pago actualizado = service.editar(pago, pagoID);
    EntityModel<Pago> recurso = EntityModel.of(actualizado);
    recurso.add(linkTo(methodOn(PagoController.class).ver(pagoID)).withSelfRel());
    recurso.add(linkTo(methodOn(PagoController.class).pagar(pagoID)).withRel("pagar"));
    return ResponseEntity.ok(recurso);
}



    //Marca Como Pagado basicamente
    
    @Operation(summary = "Permite marcar un pago como pagado")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Actualiza el estado del pago identificado por su ID a 'pagado' y devuelve el objeto actualizado",
        content = @Content(schema = @Schema(implementation = Pago.class))
    ),
    @ApiResponse(
        responseCode = "400",
        description = "ID inválido o el pago no puede ser marcado como pagado"
    ),
    @ApiResponse(
        responseCode = "404",
        description = "Pago no encontrado con el ID proporcionado"
    )
})


 @PatchMapping("/pagar/{pagoID}")
public ResponseEntity<EntityModel<Pago>> pagar(@PathVariable Long pagoID) {
    Pago pagado = service.pagar(pagoID);
    EntityModel<Pago> recurso = EntityModel.of(pagado);
    recurso.add(linkTo(methodOn(PagoController.class).ver(pagoID)).withSelfRel());
    return ResponseEntity.ok(recurso);
}






    //verPago

@Operation(summary = "Permite obtener un pago existente por su ID")
@ApiResponses(value = {
    @ApiResponse(
        responseCode = "200",
        description = "Devuelve los detalles completos del pago identificado por su ID",
        content = @Content(schema = @Schema(implementation = Pago.class))
    ),
    @ApiResponse(
        responseCode = "404",
        description = "Pago no encontrado con el ID proporcionado"
    )
})

 @GetMapping("/{pagoID}")
public ResponseEntity<EntityModel<Pago>> ver(@PathVariable Long pagoID) {
    Pago pago = service.ver(pagoID);
    EntityModel<Pago> recurso = EntityModel.of(pago);
    recurso.add(linkTo(methodOn(PagoController.class).editar(null, pagoID)).withRel("editar"));
    recurso.add(linkTo(methodOn(PagoController.class).pagar(pagoID)).withRel("pagar"));
    return ResponseEntity.ok(recurso);
}




}
