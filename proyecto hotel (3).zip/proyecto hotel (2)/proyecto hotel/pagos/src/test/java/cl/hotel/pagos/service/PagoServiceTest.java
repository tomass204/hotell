package cl.hotel.pagos.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import cl.hotel.pagos.model.Pago;
import cl.hotel.pagos.repository.PagoRepository;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PagoServiceTest {
    @Mock
    private PagoRepository repository;

    @InjectMocks
    private PagoService service;

    @Test
    void crearPago() {
        Map<String, Object> mapPago = new HashMap<>();
        mapPago.put("medioPago", "Transferencia");
        mapPago.put("totalPago", 500000);

        Pago pago = new Pago();
        pago.setPagoID(1L);
        pago.setMedioPago("Transferencia");
        pago.setTotalPago(500000);
        pago.setPagado(false);

        when(repository.save(any(Pago.class))).thenReturn(pago);

        Pago pagoCreado = service.crear(mapPago);

        assertNotNull(pagoCreado);
        assertEquals(pago.getPagoID(), pagoCreado.getPagoID());
        assertEquals(pago.getMedioPago(), pagoCreado.getMedioPago());
        assertEquals(pago.getTotalPago(), pagoCreado.getTotalPago());
        assertFalse(pagoCreado.getPagado());
    }

    @Test
    void editarPago() {
        Long pagoID = 1L;

        Pago pago = new Pago();
        pago.setPagoID(pagoID);
        pago.setMedioPago("Transferencia");
        pago.setTotalPago(500000);
        pago.setPagado(false);

        when(repository.findById(pagoID)).thenReturn(Optional.of(pago));
        when(repository.save(any(Pago.class))).thenReturn(pago);

        Map<String, Object> mapPago = new HashMap<>();
        mapPago.put("medioPago", "Transferencia");
        mapPago.put("totalPago", 500000);

        Pago pagoEditado = service.editar(mapPago, pagoID);

        assertNotNull(pagoEditado);
        assertEquals(pago.getPagoID(), pagoEditado.getPagoID());
        assertEquals(pago.getMedioPago(), pagoEditado.getMedioPago());
        assertEquals(pago.getTotalPago(), pagoEditado.getTotalPago());
    }

    @Test
    void pagarPago() {
        Long pagoID = 1L;

        Pago pago = new Pago();
        pago.setPagoID(pagoID);
        pago.setPagado(false);

        when(repository.findById(pagoID)).thenReturn(Optional.of(pago));
        when(repository.save(any(Pago.class))).thenAnswer(invocation -> {
            Pago p = invocation.getArgument(0);
            p.setPagado(true);
            return p;
        });

        Pago pagoPagado = service.pagar(pagoID);

        assertNotNull(pagoPagado);
        assertTrue(pagoPagado.getPagado());
        assertEquals(pagoID, pagoPagado.getPagoID());
    }

    @Test
    void verPago() {
        Long pagoID = 1L;
        Pago pago = new Pago();
        pago.setPagoID(pagoID);
        pago.setPagado(false);
        pago.setMedioPago("Transferencia");
        pago.setTotalPago(500000);

        when(repository.findById(pagoID)).thenReturn(Optional.of(pago));
        when(repository.save(any(Pago.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Pago pagoVerificado = service.ver(pagoID);

        assertNotNull(pagoVerificado);
        assertEquals(pago.getMedioPago(), pagoVerificado.getMedioPago());
    }
}
