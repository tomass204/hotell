package cl.hotel.pagos.controller;

import cl.hotel.pagos.model.Pago;
import cl.hotel.pagos.service.PagoService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(PagoController.class)
class PagoControllerTest {

    @MockBean
    private PagoService service;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void crearPago() throws Exception {
        Pago pago = new Pago();
        pago.setPagoID(1L);
        pago.setMedioPago("Transferencia");
        pago.setTotalPago(500000);
        pago.setPagado(false);

        when(service.crear(anyMap())).thenReturn(pago);

        String json = "{\n" +
                "  \"medioPago\": \"Transferencia\",\n" +
                "  \"totalPago\": 500000\n" +
                "}";

        try {
            mockMvc.perform(post("/api/hotel/v1/pagos")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pagoID").value(1L))
                .andExpect(jsonPath("$.medioPago").value("Transferencia"))
                .andExpect(jsonPath("$.totalPago").value(500000))
                .andExpect(jsonPath("$.pagado").value(false));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void editarPago() throws Exception {
        Pago pago = new Pago();
        pago.setPagoID(1L);
        pago.setMedioPago("Transferencia");
        pago.setTotalPago(500000);
        pago.setPagado(false);

        when(service.editar(anyMap(), eq(1L))).thenReturn(pago);

        String json = "{\n" +
                "  \"medioPago\": \"Transferencia\",\n" +
                "  \"totalPago\": 500000\n" +
                "}";

        try {
            mockMvc.perform(put("/api/hotel/v1/pagos/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pagoID").value(1L))
                .andExpect(jsonPath("$.medioPago").value("Transferencia"))
                .andExpect(jsonPath("$.totalPago").value(500000));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void pagarPago() throws Exception {
        Pago pago = new Pago();
        pago.setPagoID(1L);
        pago.setPagado(false);

        when(service.pagar(1L)).thenReturn(pago);

        try {
            mockMvc.perform(patch("/api/hotel/v1/pagos/pagar/1"))
                .andExpect(status().isOk());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void verPago() throws Exception {
        Pago pago = new Pago();
        pago.setPagoID(1L);
        pago.setMedioPago("Transferencia");
        pago.setTotalPago(500000);
        pago.setPagado(false);

        when(service.ver(1L)).thenReturn(pago);

        try {
            mockMvc.perform(get("/api/hotel/v1/pagos/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.pagoID").value(1L))
                .andExpect(jsonPath("$.medioPago").value("Transferencia"))
                .andExpect(jsonPath("$.totalPago").value(500000))
                .andExpect(jsonPath("$.pagado").value(false));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
