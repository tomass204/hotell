package cl.hotel.habitaciones.controller;


import cl.hotel.habitaciones.model.Habitacion;
import cl.hotel.habitaciones.service.HabitacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/habitaciones")
public class HabitacionController {

    @Autowired
    private HabitacionService service;

    @Operation(summary = "Permite crear una habitación con sus características")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Recibe un Map<String, Object> que representa las características de la habitación y crea una nueva", content = @Content(schema = @Schema(implementation = Habitacion.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para crear la habitación")
    })
    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Map<String,Object> habitacion){
        try {
            Habitacion nueva = service.crear(habitacion);
            EntityModel<Habitacion> recurso = EntityModel.of(nueva);
            recurso.add(linkTo(methodOn(HabitacionController.class).ver(nueva.getHabitacionID())).withSelfRel());
            recurso.add(linkTo(methodOn(HabitacionController.class).editar(null, nueva.getHabitacionID())).withRel("editar"));
            recurso.add(linkTo(methodOn(HabitacionController.class).cambiarEstado(nueva.getHabitacionID(), !nueva.getActivo())).withRel(nueva.getActivo() ? "desactivar" : "activar"));
            return ResponseEntity.ok(recurso);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @Operation(summary = "Permite editar una habitación existente con sus datos actualizados")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Recibe un Map<String, Object> con los nuevos datos para actualizar una habitación existente", content = @Content(schema = @Schema(implementation = Habitacion.class))),
        @ApiResponse(responseCode = "400", description = "Datos inválidos para actualizar la habitación")
    })
    @PutMapping("/{habitacionID}")
    public ResponseEntity<EntityModel<Habitacion>> editar(@RequestBody Map<String,Object> habitacion, @PathVariable Long habitacionID){
        Habitacion editada = service.editar(habitacion, habitacionID);
        EntityModel<Habitacion> recurso = EntityModel.of(editada);
        recurso.add(linkTo(methodOn(HabitacionController.class).ver(habitacionID)).withSelfRel());
        recurso.add(linkTo(methodOn(HabitacionController.class).cambiarEstado(habitacionID, !editada.getActivo())).withRel(editada.getActivo() ? "desactivar" : "activar"));
        return ResponseEntity.ok(recurso);
    }

    @Operation(summary = "Permite cambiar el estado (activar/desactivar) de una habitación")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Modifica parcialmente una habitación para cambiar su estado", content = @Content(schema = @Schema(implementation = Habitacion.class))),
        @ApiResponse(responseCode = "400", description = "ID inválido o la habitación no puede ser modificada")
    })
    @PatchMapping("/cambiar-estado/{habitacionID}")
    public ResponseEntity<EntityModel<Habitacion>> cambiarEstado(@PathVariable Long habitacionID, @RequestParam boolean activar){
        Habitacion actualizada = activar ? service.activar(habitacionID) : service.desactivar(habitacionID);
        EntityModel<Habitacion> recurso = EntityModel.of(actualizada);
        recurso.add(linkTo(methodOn(HabitacionController.class).ver(habitacionID)).withSelfRel());
        recurso.add(linkTo(methodOn(HabitacionController.class).cambiarEstado(habitacionID, !activar)).withRel(activar ? "desactivar" : "activar"));
        return ResponseEntity.ok(recurso);
    }

    @Operation(summary = "Permite obtener una habitación existente por su ID")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve los detalles completos de una habitación dado su ID", content = @Content(schema = @Schema(implementation = Habitacion.class))),
        @ApiResponse(responseCode = "404", description = "Habitación no encontrada con el ID proporcionado")
    })
    @GetMapping("/{habitacionID}")
    public ResponseEntity<EntityModel<Habitacion>> ver(@PathVariable Long habitacionID){
        Habitacion vista = service.ver(habitacionID);
        EntityModel<Habitacion> recurso = EntityModel.of(vista);
        recurso.add(linkTo(methodOn(HabitacionController.class).editar(null, habitacionID)).withRel("editar"));
        recurso.add(linkTo(methodOn(HabitacionController.class).cambiarEstado(habitacionID, !vista.getActivo())).withRel(vista.getActivo() ? "desactivar" : "activar"));
        return ResponseEntity.ok(recurso);
    }

    @Operation(summary = "Permite obtener la lista de todas las habitaciones")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve una lista con todas las habitaciones registradas", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Habitacion.class))))
    })
    @GetMapping("/listar")
    public ResponseEntity<CollectionModel<EntityModel<Habitacion>>> listahabitaciones(){
        List<EntityModel<Habitacion>> habitaciones = service.listahabitaciones().stream()
            .map(h -> EntityModel.of(h,
                linkTo(methodOn(HabitacionController.class).ver(h.getHabitacionID())).withSelfRel(),
                linkTo(methodOn(HabitacionController.class).cambiarEstado(h.getHabitacionID(), !h.getActivo())).withRel(h.getActivo() ? "desactivar" : "activar")
            )).toList();
        return ResponseEntity.ok(CollectionModel.of(habitaciones,
            linkTo(methodOn(HabitacionController.class).listahabitaciones()).withSelfRel()));
    }

    @Operation(summary = "Permite obtener la lista de habitaciones activas disponibles")
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Devuelve una lista con todas las habitaciones que están activas", content = @Content(array = @ArraySchema(schema = @Schema(implementation = Habitacion.class))))
    })
    @GetMapping("/listar-activos")
    public ResponseEntity<CollectionModel<EntityModel<Habitacion>>> listaHabitacionesActivas(){
        List<EntityModel<Habitacion>> habitaciones = service.listaHabitacionesActivas().stream()
            .map(h -> EntityModel.of(h,
                linkTo(methodOn(HabitacionController.class).ver(h.getHabitacionID())).withSelfRel(),
                linkTo(methodOn(HabitacionController.class).cambiarEstado(h.getHabitacionID(), false)).withRel("desactivar")
            )).toList();
        return ResponseEntity.ok(CollectionModel.of(habitaciones,
            linkTo(methodOn(HabitacionController.class).listaHabitacionesActivas()).withSelfRel()));
    }
}
