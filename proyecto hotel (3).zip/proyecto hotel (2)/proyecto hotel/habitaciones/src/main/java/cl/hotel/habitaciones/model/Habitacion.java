package cl.hotel.habitaciones.model;

import io.swagger.v3.oas.annotations.media.Schema; // 🔁 Importación para Swagger

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "habitaciones")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Schema(description = "Entidad que representa una habitación del hotel")
public class Habitacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "habitacion_id")
    @Schema(description = "ID único de la habitación", example = "1")
    private Long habitacionID;

    @Column(nullable = false)
    @Schema(description = "Descripción de la habitación", example = "Habitación doble con baño privado", required = true)
    private String descripcion;

    @Column(nullable = false, name = "valor_por_dia")
    @Schema(description = "Valor por día de la habitación", example = "45000", required = true)
    private Integer valorPorDia;

    @Column(nullable = false)
    @Schema(description = "Número de habitación", example = "203", required = true)
    private Integer numero;

    @Column(nullable = false)
    @Schema(description = "Indica si la habitación está activa", example = "true", required = true)
    private Boolean activo;
}

