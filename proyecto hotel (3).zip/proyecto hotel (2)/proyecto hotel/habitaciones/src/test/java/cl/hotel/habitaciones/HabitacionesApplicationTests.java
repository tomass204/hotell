package cl.hotel.habitaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HabitacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
