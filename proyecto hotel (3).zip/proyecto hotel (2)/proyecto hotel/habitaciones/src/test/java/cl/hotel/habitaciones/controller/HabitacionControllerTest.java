package cl.hotel.habitaciones.controller;

import cl.hotel.habitaciones.model.Habitacion;
import cl.hotel.habitaciones.service.HabitacionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.Mockito.when;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.ArgumentMatchers.eq;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;

@WebMvcTest(HabitacionController.class)
class HabitacionControllerTest {

    @MockBean
    private HabitacionService service;

    @Autowired
    private MockMvc mockMvc;

    @Test
    void crearHabitacion() throws Exception {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setDescripcion("Habitación simple");
        habitacion.setValorPorDia(5000);
        habitacion.setNumero(1);
        habitacion.setActivo(true);

        when(service.crear(anyMap())).thenReturn(habitacion);

        String json = "{\n" +
                "  \"descripcion\": \"Habitación simple\",\n" +
                "  \"valorPorDia\": 5000,\n" +
                "  \"numero\": 1\n" +
                "}";

        try {
            mockMvc.perform(post("/api/hotel/v1/habitaciones")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.habitacionID").value(1L))
                .andExpect(jsonPath("$.descripcion").value("Habitación simple"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void editarHabitacion() throws Exception {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setDescripcion("Habitación simple");
        habitacion.setValorPorDia(6000);
        habitacion.setActivo(true);

        when(service.editar(anyMap(), eq(1L))).thenReturn(habitacion);

        String json = "{\n" +
                "  \"descripcion\": \"Habitación simple\",\n" +
                "  \"valorPorDia\": 6000\n" +
                "}";

        try {
            mockMvc.perform(put("/api/hotel/v1/habitaciones/1")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(json))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.habitacionID").value(1L))
                .andExpect(jsonPath("$.valorPorDia").value(6000));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void activarHabitacion() throws Exception {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setActivo(true);

        when(service.activar(1L)).thenReturn(habitacion);

        try {
            mockMvc.perform(patch("/api/hotel/v1/habitaciones/cambiar-estado/1")
                .param("activar", "true"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activo").value(true));
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    @Test
    void desactivarHabitacion() throws Exception {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setActivo(false);

        when(service.desactivar(1L)).thenReturn(habitacion);

        try {
            mockMvc.perform(patch("/api/hotel/v1/habitaciones/cambiar-estado/1")
                .param("activar", "false"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.activo").value(false));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void verHabitacion() throws Exception {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setDescripcion("Habitación simple");
        habitacion.setValorPorDia(5000);
        habitacion.setActivo(true);

        when(service.ver(1L)).thenReturn(habitacion);

        try {
            mockMvc.perform(get("/api/hotel/v1/habitaciones/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.habitacionID").value(1L))
                .andExpect(jsonPath("$.descripcion").value("Habitación simple"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void listarHabitaciones() throws Exception {
        List<Habitacion> habitaciones = List.of(new Habitacion());
        habitaciones.get(0).setHabitacionID(1L);
        habitaciones.get(0).setDescripcion("Habitación simple");
        habitaciones.get(0).setValorPorDia(5000);
        habitaciones.get(0).setNumero(1);
        habitaciones.get(0).setActivo(true);

        when(service.listahabitaciones()).thenReturn(habitaciones);

        try {
            mockMvc.perform(get("/api/hotel/v1/habitaciones/listar"))
                .andDo(result -> System.out.println("Response: " + result.getResponse().getContentAsString()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.habitacionList[0].habitacionID").value(1L))
                .andExpect(jsonPath("$._embedded.habitacionList[0].descripcion").value("Habitación simple"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Test
    void listarHabitacionesActivas() throws Exception {
        List<Habitacion> habitaciones = List.of(new Habitacion());
        habitaciones.get(0).setHabitacionID(1L);
        habitaciones.get(0).setDescripcion("Habitación simple");
        habitaciones.get(0).setValorPorDia(5000);
        habitaciones.get(0).setActivo(true);

        when(service.listaHabitacionesActivas()).thenReturn(habitaciones);

        try {
            mockMvc.perform(get("/api/hotel/v1/habitaciones/listar-activos"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$._embedded.habitacionList[0].activo").value(true));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
