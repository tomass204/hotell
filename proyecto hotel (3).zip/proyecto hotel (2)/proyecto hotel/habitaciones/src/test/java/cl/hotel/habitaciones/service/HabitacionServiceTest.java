package cl.hotel.habitaciones.service;

import cl.hotel.habitaciones.model.Habitacion;
import cl.hotel.habitaciones.repository.HabitacionRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class HabitacionServiceTest {

    @Mock
    private HabitacionRepository repository;

    @InjectMocks
    private HabitacionService service;

    @BeforeEach
    void setUp() {
        // Any setup if needed
    }

    @Test
    void crearHabitacion() {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setDescripcion("Habitación simple");
        habitacion.setValorPorDia(5000);
        habitacion.setNumero(1);
        habitacion.setActivo(true);

        Map<String, Object> datos = new HashMap<>();
        datos.put("descripcion", "Habitación simple");
        datos.put("valorPorDia", 5000);
        datos.put("numero", 1);

        when(repository.save(any(Habitacion.class))).thenReturn(habitacion);

        Habitacion resultado = service.crear(datos);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getHabitacionID());
        assertEquals("Habitación simple", resultado.getDescripcion());
        assertEquals(5000, resultado.getValorPorDia());
        assertEquals(1, resultado.getNumero());
        assertTrue(resultado.getActivo());

        verify(repository).save(any(Habitacion.class));
    }

    @Test
    void editarHabitacion() {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setDescripcion("Habitación simple");
        habitacion.setValorPorDia(6000);
        habitacion.setActivo(true);

        Map<String, Object> datos = new HashMap<>();
        datos.put("descripcion", "Habitación simple");
        datos.put("valorPorDia", 6000);
        datos.put("numero", 1);

        when(repository.findById(eq(1L))).thenReturn(java.util.Optional.of(habitacion));
        when(repository.save(any(Habitacion.class))).thenReturn(habitacion);

        Habitacion resultado = service.editar(datos, 1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getHabitacionID());
        assertEquals("Habitación simple", resultado.getDescripcion());
        assertEquals(6000, resultado.getValorPorDia());
        assertTrue(resultado.getActivo());

        verify(repository).findById(eq(1L));
        verify(repository).save(any(Habitacion.class));
    }

    @Test
    void activarHabitacion() {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setActivo(true);

        when(repository.findById(eq(1L))).thenReturn(java.util.Optional.of(habitacion));
        when(repository.save(any(Habitacion.class))).thenReturn(habitacion);

        Habitacion resultado = service.activar(1L);

        assertNotNull(resultado);
        assertTrue(resultado.getActivo());
        verify(repository).findById(eq(1L));
        verify(repository).save(any(Habitacion.class));
    }

    @Test
    void desactivarHabitacion() {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setActivo(false);

        when(repository.findById(eq(1L))).thenReturn(java.util.Optional.of(habitacion));
        when(repository.save(any(Habitacion.class))).thenReturn(habitacion);

        Habitacion resultado = service.desactivar(1L);

        assertNotNull(resultado);
        assertFalse(resultado.getActivo());
        verify(repository).findById(eq(1L));
        verify(repository).save(any(Habitacion.class));
    }

    @Test
    void verHabitacion() {
        Habitacion habitacion = new Habitacion();
        habitacion.setHabitacionID(1L);
        habitacion.setDescripcion("Habitación simple");
        habitacion.setValorPorDia(5000);
        habitacion.setActivo(true);

        when(repository.findById(eq(1L))).thenReturn(java.util.Optional.of(habitacion));
        when(repository.save(any(Habitacion.class))).thenReturn(habitacion);

        Habitacion resultado = service.ver(1L);

        assertNotNull(resultado);
        assertEquals(1L, resultado.getHabitacionID());
        assertEquals("Habitación simple", resultado.getDescripcion());
        assertEquals(5000, resultado.getValorPorDia());
        assertTrue(resultado.getActivo());
        verify(repository).findById(eq(1L));
        verify(repository).save(any(Habitacion.class));
    }

    @Test
    void listarHabitaciones() {
        List<Habitacion> habitaciones = new ArrayList<>();
        Habitacion habitacion1 = new Habitacion();
        habitacion1.setHabitacionID(1L);
        habitacion1.setDescripcion("Habitación simple");
        habitacion1.setValorPorDia(5000);
        habitacion1.setNumero(1);
        habitacion1.setActivo(true);
        habitaciones.add(habitacion1);

        when(repository.findAll()).thenReturn(habitaciones);

        List<Habitacion> resultado = service.listahabitaciones();

        assertNotNull(resultado);
        assertFalse(resultado.isEmpty());
        assertEquals(1, resultado.size());
        assertEquals(1L, resultado.get(0).getHabitacionID());
        assertEquals("Habitación simple", resultado.get(0).getDescripcion());
        verify(repository).findAll();
    }

    @Test
    void listarHabitacionesActivas() {
        List<Habitacion> habitaciones = new ArrayList<>();
        Habitacion habitacion1 = new Habitacion();
        habitacion1.setHabitacionID(1L);
        habitacion1.setDescripcion("Habitación simple");
        habitacion1.setValorPorDia(5000);
        habitacion1.setActivo(true);
        habitaciones.add(habitacion1);

        when(repository.findAllByActivoTrue()).thenReturn(habitaciones);

        List<Habitacion> resultado = service.listaHabitacionesActivas();

        assertNotNull(resultado);
        assertFalse(resultado.isEmpty());
        assertTrue(resultado.get(0).getActivo());
        verify(repository).findAllByActivoTrue();
    }
}
