package com.example.Hotel.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.Hotel.model.Cliente;

@Repository
public interface ClienteRepository extends JpaRepository <Cliente, Long>{

    @Query("SELECT p FROM Cliente p WHERE p.Ticket = :ticket")
    List<Cliente> BuscarPorTicket (@Param("Tickes")String ticket);

    @Query(value = "SELECT * FROM cliente WHERE run= :rut", nativeQuery = true)
    Cliente buscarclienteRut(@Param("run")String rut);

}
