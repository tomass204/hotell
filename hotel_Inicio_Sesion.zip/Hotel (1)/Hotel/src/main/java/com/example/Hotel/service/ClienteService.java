package com.example.Hotel.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Hotel.model.Cliente;
import com.example.Hotel.repository.ClienteRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class ClienteService {
    @Autowired
    private ClienteRepository clienteRepository;

    public List<Cliente> listarClientes(){
        return clienteRepository.findAll();
    }

    public Cliente buscarClientePorTicket(long ticket){
        return clienteRepository.findById(ticket).get();
    }
    public Cliente saveCliente(Cliente cliente){
        return clienteRepository.save(cliente);
    }
    public void borrerCliente(long rut){
        clienteRepository.deleteById(rut);
    }
}
