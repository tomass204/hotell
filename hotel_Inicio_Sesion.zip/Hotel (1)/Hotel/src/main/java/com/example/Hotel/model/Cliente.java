package com.example.Hotel.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table (name= "usuarios")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Cliente {
    @Id
    @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Integer Ticket;

    @Column(unique = true, length = 12, nullable = false)
    private String run;

    @Column(nullable =  false,length  =  100)
    private String  Rol;

    @Column(nullable = false)
    private String correo;

    @Column(nullable = false)
    private String contraseña;

}
