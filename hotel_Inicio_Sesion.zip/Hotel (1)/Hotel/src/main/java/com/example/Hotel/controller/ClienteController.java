package com.example.Hotel.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Hotel.model.Cliente;
import com.example.Hotel.service.ClienteService;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;




@RestController
@RequestMapping ("/api/v1/Clientes")
public class ClienteController {

    @Autowired
    private ClienteService clienteService;

    @GetMapping
    public ResponseEntity<List<Cliente>> listar(){
        List<Cliente> clientes = clienteService.listarClientes();
        if(clientes.isEmpty()){
            return ResponseEntity.noContent().build();
    }  
    return ResponseEntity.ok(clientes); 
    
} 

@PostMapping
public ResponseEntity<Cliente> guardarCliente(@RequestBody Cliente cliente){
    Cliente pac = clienteService.saveCliente(cliente);
    return ResponseEntity.status(HttpStatus.CREATED).body(pac);

} 
@GetMapping("/{ticket }")
public ResponseEntity<Cliente> buscarClientePorTicket(@PathVariable Integer ticket){
    try {
        Cliente pac = clienteService.buscarClientePorTicket (ticket);
        return ResponseEntity.ok(pac);
    } catch (Exception e){
        return ResponseEntity.notFound().build();
    } 
} 
    @DeleteMapping("/{Ticket}")
    public ResponseEntity<?>  borrarClientePorTicket(@PathVariable Long ticket){
        try{
            Cliente pac = clienteService.buscarClientePorTicket(ticket);
            clienteService.borrerCliente(ticket);
            return ResponseEntity.noContent().build();
        }catch (Exception e) {
            return ResponseEntity.notFound().build();
    }

} 
@PutMapping("/{Ticket}")
public ResponseEntity<Cliente> actualizarClientePorTicket(@PathVariable Integer ticket, @RequestBody Cliente pac){
    try {
        Cliente cliente2 = clienteService.buscarClientePorTicket(ticket);
        cliente2.setTicket(ticket);
        cliente2.setRun(pac.getRun());
        cliente2.setRol(pac.getRol());
        cliente2.getCorreo();
        cliente2.getContraseña();

        clienteService.saveCliente(cliente2);
        return ResponseEntity.ok(cliente2);




} catch (Exception e){
    return ResponseEntity.notFound().build();

} 




} 

} 
