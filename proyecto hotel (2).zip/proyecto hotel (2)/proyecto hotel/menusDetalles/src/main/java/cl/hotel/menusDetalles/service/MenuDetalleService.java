package cl.hotel.menusDetalles.service;

import cl.hotel.menusDetalles.model.MenuDetalle;
import cl.hotel.menusDetalles.repository.MenuDetalleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class MenuDetalleService {

    @Autowired
    private MenuDetalleRepository repository;

    public MenuDetalle crear( MenuDetalle menuDetalle) {
        menuDetalle.setMenuDetalleID(null);
        return repository.save(menuDetalle);
    }

    public List<MenuDetalle> crearMenuReserva( List<MenuDetalle> menuDetalle, Long reservaID) {
        menuDetalle.forEach(detalle -> {
            detalle.setReservaID(reservaID);
            detalle.setMenuDetalleID(null);
        });
        return repository.saveAll(menuDetalle);
    }


    public MenuDetalle editar(MenuDetalle menuDetalle, Long menuDetalleID) {
        menuDetalle.setMenuDetalleID(menuDetalleID);
        return  repository.save(menuDetalle);
    }

    public MenuDetalle eliminar(Long menuDetalleID) {
        Optional<MenuDetalle> menuDetalleOptional = repository.findById(menuDetalleID);
        if (!menuDetalleOptional.isPresent()) {
            throw new RuntimeException("No existe el detalle a eliminar.");
        }
        MenuDetalle menuDetalle=menuDetalleOptional.get();
        repository.deleteById(menuDetalleID);
        return menuDetalle;
    }


    public MenuDetalle ver(Long menuDetalleID) {
        Optional<MenuDetalle> menuDetalleOptional = repository.findById(menuDetalleID);
        if (!menuDetalleOptional.isPresent()) {
            throw new RuntimeException("No existe el detalle.");
        }
        return menuDetalleOptional.get();
    }

    public List<MenuDetalle> listarPorReserva(Long reservaID) {
        return repository.findAllByReservaID(reservaID);
    }


}
