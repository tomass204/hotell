package cl.hotel.menusDetalles;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenusDetallesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MenusDetallesApplication.class, args);
	}

}
