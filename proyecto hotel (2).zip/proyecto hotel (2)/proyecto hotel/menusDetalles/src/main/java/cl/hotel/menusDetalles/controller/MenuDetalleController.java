package cl.hotel.menusDetalles.controller;


import cl.hotel.menusDetalles.model.MenuDetalle;
import cl.hotel.menusDetalles.service.MenuDetalleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/hotel/v1/menu-detalles")
public class MenuDetalleController {

    @Autowired
    private MenuDetalleService service;

    @PostMapping
    public ResponseEntity<MenuDetalle> crear(@RequestBody MenuDetalle menuDetalle) {
        return ResponseEntity.ok(service.crear(menuDetalle));
    }

    @PostMapping("/reserva/{reservaID}")
    public ResponseEntity<List<MenuDetalle>> crearMenuReserva(@RequestBody List<MenuDetalle> menuDetalle, @PathVariable Long reservaID) {
        return ResponseEntity.ok(service.crearMenuReserva(menuDetalle, reservaID));
    }


    @PutMapping("/{menuDetalleID}")
    public ResponseEntity<MenuDetalle> editar(@RequestBody MenuDetalle menuDetalle, @PathVariable Long menuDetalleID) {
        return ResponseEntity.ok(service.editar(menuDetalle, menuDetalleID));
    }

    @DeleteMapping("/{menuDetalleID}")
    public ResponseEntity<MenuDetalle> eliminar(@PathVariable Long menuDetalleID) {
        return ResponseEntity.ok(service.eliminar(menuDetalleID));
    }


    @GetMapping("/{menuDetalleID}")
    public ResponseEntity<MenuDetalle> ver(@PathVariable Long menuDetalleID) {
        return ResponseEntity.ok(service.ver(menuDetalleID));
    }

    @GetMapping("/reserva/{reservaID}")
    public ResponseEntity<List<MenuDetalle>> listarPorReserva(@PathVariable Long reservaID) {
        return ResponseEntity.ok(service.listarPorReserva(reservaID));
    }



}
