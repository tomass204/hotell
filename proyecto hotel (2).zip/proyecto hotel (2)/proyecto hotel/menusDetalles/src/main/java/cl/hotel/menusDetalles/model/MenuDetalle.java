package cl.hotel.menusDetalles.model;

import java.time.LocalDate;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "menusdetalles")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuDetalle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "menu_detalle_id")
    private Long menuDetalleID;
    @Column(name = "menu_id", nullable = false)
    private Long menuID;
    @Column(name = "reserva_id", nullable = false)
    private Long reservaID;
    @Column(nullable = false)
    private LocalDate fecha;
    @Column(nullable = false)
    private Integer cantidad;

    @ManyToOne
    @JoinColumn(name = "menu_id", insertable = false, updatable = false)
    private Menu menu;

}
