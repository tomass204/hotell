package cl.hotel.menusDetalles.repository;

import cl.hotel.menusDetalles.model.MenuDetalle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface MenuDetalleRepository extends JpaRepository<MenuDetalle,Long> {

    List<MenuDetalle> findAllByReservaID(Long reservaID);

}
