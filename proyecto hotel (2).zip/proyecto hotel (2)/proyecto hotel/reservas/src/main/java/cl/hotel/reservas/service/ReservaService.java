package cl.hotel.reservas.service;

import cl.hotel.reservas.model.Reserva;
import cl.hotel.reservas.repository.ReservaRepository;
import cl.hotel.reservas.webclient.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository repository;

    @Autowired
    private AutoClient autoClient;
    @Autowired
    private ClienteClient clienteClient;
    @Autowired
    private MenuClient menuClient;
    @Autowired
    private MenuDetallesClient menuDetallesClient;
    @Autowired
    private PagoClient pagoClient;
    @Autowired
    private HabitacionClient habitacionClient;


    public Map<String, Object> crearReserva(Map<String, Object> reserva) {

        Integer totalPago=0;
        LocalDate fechaInicio=LocalDate.parse(String.valueOf(reserva.get("fechaInicio")));
        LocalDate fechaFin=LocalDate.parse(String.valueOf(reserva.get("fechaFin")));
        long diasReservados = ChronoUnit.DAYS.between(fechaInicio, fechaFin) + 1;


        final Long clienteID=Long.valueOf(String.valueOf(reserva.get("clienteID")));
        Map<String,Object> cliente=clienteClient.getClienteById(clienteID);
        if(cliente==null || cliente.isEmpty()){
            throw new RuntimeException("Cliente no encontrado. No se puede crear la reserva");
        }

        if(!cliente.containsKey("activo") || !Boolean.valueOf(String.valueOf(cliente.get("activo")))){
            throw new RuntimeException("El cliente no esta activo. No se puede crear la reserva");
        }

        final Long habitacionID=Long.valueOf(String.valueOf(reserva.get("habitacionID")));
        Map<String,Object> habitacion=habitacionClient.getHabitacionById(habitacionID);
        if(habitacion==null || habitacion.isEmpty()){
            throw new RuntimeException("habitación no encontrada. No se puede crear la reserva");
        }

        if(!habitacion.containsKey("activo") || !Boolean.valueOf(String.valueOf(habitacion.get("activo")))){
            throw new RuntimeException("La habitación no esta activa. No se puede crear la reserva");
        }
        Integer totalHabitacion= Math.toIntExact(diasReservados * Integer.valueOf(String.valueOf(habitacion.get("valorPorDia"))));

        Map<String,Object> auto=new HashMap<>();
        Integer totalAuto=0;
        Long autoID=null;
        if(reserva.containsKey("autoID") && Long.valueOf(String.valueOf(reserva.get("autoID")))>0){
            autoID=Long.valueOf(String.valueOf(reserva.get("autoID")));
            auto=autoClient.getAutoById(autoID);
            if(cliente==null || cliente.isEmpty()){
                throw new RuntimeException("Auto no encontrado. No se puede crear la reserva");
            }

            if(!cliente.containsKey("activo") || !Boolean.valueOf(String.valueOf(auto.get("activo")))){
                throw new RuntimeException("El auto no esta activo. No se puede crear la reserva");
            }
            totalAuto=Integer.valueOf(String.valueOf(auto.get("valor")));
        }

        List<Map<String, Object>> menusDetalles = (List<Map<String, Object>>) reserva.get("menus");
        if(menusDetalles==null || menusDetalles.isEmpty()){
            throw new RuntimeException("El menu esta vacio.");
        }

        Integer totalMenu=0;
        for(Map<String, Object> menuDetalle: menusDetalles){
            Long menuID=Long.valueOf(String.valueOf(menuDetalle.get("menuID")));
            Map<String,Object> menu = menuClient.getMenuById(menuID);
            if(menu==null || menu.isEmpty()){
                throw new RuntimeException("menu no encontrado. No se puede crear la reserva");
            }
            Integer cantidad=Integer.valueOf(String.valueOf(menuDetalle.get("cantidad")));
            Integer valor=Integer.valueOf(String.valueOf(menu.get("valor")));
            Integer total=cantidad*valor;
            totalMenu=totalMenu+total;
        }

        totalPago=totalAuto+totalHabitacion+totalMenu;

        //pago
        Map<String,Object> pago=Map.of("medioPago", "tarjeta",
                "totalPago", totalPago);
        pago=pagoClient.crearPago(pago);
        if(pago==null || pago.isEmpty()){
            throw new RuntimeException("Error al crear el pago. No se puede crear la reserva");
        }
        if(!pago.containsKey("pagoID")){
            throw new RuntimeException("Error al crear el pago. No se puede crear la reserva");
        }
        Long pagoID=Long.valueOf(String.valueOf(pago.get("pagoID")));

        Reserva reservaModel = new Reserva();
        reservaModel.setClienteID(clienteID);
        reservaModel.setHabitacionID(habitacionID);
        reservaModel.setAutoID(autoID);
        reservaModel.setAnulado(false);
        reservaModel.setFechaInicio(fechaInicio);
        reservaModel.setFechaFin(fechaFin);
        reservaModel.setReservaID(null);
        reservaModel.setPagoID(pagoID);
        reservaModel=repository.save(reservaModel);

        menusDetalles=menuDetallesClient.crearMenuReserva(menusDetalles, reservaModel.getReservaID());
        if(menusDetalles==null || menusDetalles.isEmpty()){
            throw new RuntimeException("Error al crear los menus. No se puede crear la reserva");
        }
        Map<String,Object> response=new HashMap<>();
        response.put("reserva",reservaModel);
        response.put("habitacion", habitacion);
        response.put("menuDetalle", menusDetalles);
        response.put("auto",auto);
        response.put("cliente", cliente);
        response.put("pago",pago);

        return response;

    }

    public Reserva anular(Long reservaID) {
        Optional<Reserva> reservaOptional = repository.findById(reservaID);
        if (!reservaOptional.isPresent()) {
            throw new RuntimeException("No existe la reserva.");
        }
        Reserva reserva = reservaOptional.get();

        Map<String,Object> pago=pagoClient.getPagoById(reserva.getPagoID());
        if(pago==null || pago.isEmpty()){
            throw new RuntimeException("Pago no encontrado. No se puede anular la reserva");
        }

        if(!pago.containsKey("pagado")){
            throw new RuntimeException("Error al recuperar estado del pago. No se puede crear la reserva");
        }

        if(Boolean.valueOf(String.valueOf(pago.get("pagado")))){
            throw new RuntimeException("La reserva ya se encuentra pagada. No se puede crear la reserva");
        }

        reserva.setAnulado(true);
        return repository.save(reserva);


    }
}
