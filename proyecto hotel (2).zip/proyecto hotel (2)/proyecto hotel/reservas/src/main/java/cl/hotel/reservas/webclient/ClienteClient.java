package cl.hotel.reservas.webclient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

@Component//Hace que Spring detecte e inyecte esta clase automáticamente.
public class ClienteClient {

    private final WebClient webClient;
    //Se construye un WebClient con esa URL base, el cual luego se usa para hacer las peticiones.
    public ClienteClient(@Value("${cliente-service.url}") String clienteServiceUrl){
        this.webClient = WebClient.builder().baseUrl(clienteServiceUrl).build();
    }

    public Map<String, Object> getClienteById(Long clienteID){
        return this.webClient.get()
        //Hace una solicitud GET al microservicio de clientes para obtener los datos de un cliente
                .uri("/{clienteID}", clienteID)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(),
                //si el cliente no existe saltara un error
                        response -> response.bodyToMono(String.class)
                                .map(body -> new RuntimeException("Cliente no encontrado")))
                .bodyToMono(Map.class).block();
                //Usa .block() para que la llamada sea sincrónica.
                //Devuelve la respuesta como un Map<String, Object> con los datos del cliente.
    }


}
