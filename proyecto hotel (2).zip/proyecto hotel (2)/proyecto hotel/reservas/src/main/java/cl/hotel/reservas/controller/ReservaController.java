package cl.hotel.reservas.controller;

import cl.hotel.reservas.model.Reserva;
import cl.hotel.reservas.service.ReservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/reservas")
public class ReservaController {

    @Autowired
    private ReservaService service;

    @PostMapping
    public ResponseEntity<Map<String,Object>> crearReserva(@RequestBody Map<String,Object> reserva){
        return ResponseEntity.ok(service.crearReserva(reserva));
    }

    @PatchMapping("/{reservaID}")
    public ResponseEntity<Reserva> anular(@PathVariable Long reservaID){
        return ResponseEntity.ok(service.anular(reservaID));
    }


}
