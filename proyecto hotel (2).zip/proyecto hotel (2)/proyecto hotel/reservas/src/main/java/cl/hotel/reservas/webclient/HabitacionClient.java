package cl.hotel.reservas.webclient;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Map;

@Component
public class HabitacionClient {

    private final WebClient webClient;

    public HabitacionClient(@Value("${habitacion-service.url}") String habitacionServiceUrl){
        this.webClient = WebClient.builder().baseUrl(habitacionServiceUrl).build();
    }

    public Map<String, Object> getHabitacionById(Long habitacionID){
        return this.webClient.get()
                .uri("/{habitacionID}", habitacionID)
                .retrieve()
                .onStatus(status -> status.is4xxClientError(),
                        response -> response.bodyToMono(String.class)
                                .map(body -> new RuntimeException("Habitación no encontrada")))
                .bodyToMono(Map.class).block();
    }

}
