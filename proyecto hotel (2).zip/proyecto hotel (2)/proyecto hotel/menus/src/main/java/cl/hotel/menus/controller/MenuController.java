package cl.hotel.menus.controller;


import cl.hotel.menus.model.Menu;
import cl.hotel.menus.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/menus")
public class MenuController {

    @Autowired
    private MenuService service;

    @PostMapping
    public ResponseEntity<Menu> crear (@RequestBody Map<String,Object> menu){
        return ResponseEntity.ok(service.crear(menu));
    }

    @PutMapping("/{menuID}")
    public ResponseEntity<Menu> editar (@RequestBody Map<String,Object> menu, @PathVariable Long menuID){
        return ResponseEntity.ok(service.editar(menu, menuID));
    }

    @PatchMapping("/activar/{menuID}")
    public ResponseEntity<Menu> activar (@PathVariable Long menuID){
        return ResponseEntity.ok(service.activar(menuID));
    }

    @PatchMapping("/desactivar/{menuID}")
    public ResponseEntity<Menu> desactivar (@PathVariable Long menuID){
        return ResponseEntity.ok(service.desactivar(menuID));
    }

    @GetMapping("/{menuID}")
    public ResponseEntity<Menu> ver(@PathVariable Long menuID){
        return ResponseEntity.ok(service.ver(menuID));
    }


    @GetMapping("/listar")
    public ResponseEntity<List<Menu>> listaMenus(){
        return ResponseEntity.ok(service.listaMenus());
    }

    @GetMapping("/listar-activos")
    public ResponseEntity<List<Menu>> listaMenusActivos(){
        return ResponseEntity.ok(service.listaMenusActivos());
    }

}
