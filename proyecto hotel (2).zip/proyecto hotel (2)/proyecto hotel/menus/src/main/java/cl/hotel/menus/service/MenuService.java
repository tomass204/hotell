package cl.hotel.menus.service;



import cl.hotel.menus.model.Menu;
import cl.hotel.menus.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class MenuService {

    @Autowired
    private MenuRepository repository;

    public Menu crear(Map<String, Object> map_menu) {
        Menu menu = new Menu();
        menu.setNombre(String.valueOf(map_menu.get("nombre")));
        menu.setDescripcion(String.valueOf(map_menu.get("descripcion")));
        menu.setValor(Integer.valueOf(String.valueOf(map_menu.get("valor"))));
        menu.setMenuID(null);
        menu.setActivo(true);
        return repository.save(menu);
    }

    public Menu editar(Map<String, Object> map_menu, Long menuID) {
        Optional<Menu> menuOptional = repository.findById(menuID);
        if (!menuOptional.isPresent()) {
            throw new RuntimeException("No existe la habitación.");
        }
        Menu menu = menuOptional.get();
        menu.setNombre(String.valueOf(map_menu.get("nombre")));
        menu.setDescripcion(String.valueOf(map_menu.get("descripcion")));
        menu.setValor(Integer.valueOf(String.valueOf(map_menu.get("valor"))));
        return repository.save(menu);
    }

    public Menu ver(Long menuID) {
        Optional<Menu> menuOptional = repository.findById(menuID);
        if (!menuOptional.isPresent()) {
            throw new RuntimeException("No existe el menu.");
        }
        return repository.save(menuOptional.get());
    }

    public Menu activar(Long menuID) {
        Optional<Menu> menuOptional = repository.findById(menuID);
        if (!menuOptional.isPresent()) {
            throw new RuntimeException("No existe el menu.");
        }
        Menu menu = menuOptional.get();
        menu.setActivo(true);
        return repository.save(menu);
    }

    public Menu desactivar(Long menuID) {
        Optional<Menu> menuOptional = repository.findById(menuID);
        if (!menuOptional.isPresent()) {
            throw new RuntimeException("No existe el menu.");
        }
        Menu menu = menuOptional.get();
        menu.setActivo(false);
        return repository.save(menu);
    }

    public List<Menu> listaMenus() {
        return repository.findAll();
    }

    public List<Menu> listaMenusActivos() {
        return repository.findAllByActivoTrue();
    }


}
