package cl.hotel.menus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MenusApplication {

	public static void main(String[] args) {
		SpringApplication.run(MenusApplication.class, args);
	}

}
