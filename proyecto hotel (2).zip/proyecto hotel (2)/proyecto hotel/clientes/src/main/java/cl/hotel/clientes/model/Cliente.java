package cl.hotel.clientes.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity //marca la clase como entidad JPA
@Table(name = "clientes") //Define el nombre que tendra en la base de datos
@Data //genera getters, setters @ToString() y más
@AllArgsConstructor //es de Lombok genera un constructor vacío
@NoArgsConstructor //genera un constructor con todos los campos.
public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "cliente_id")
    private Long clienteID; //se genera automáticamente

    //Define los atributos que tendra el cliente
    @Column(nullable = false)
    private String run;
    @Column(nullable = false)
    private String nombres;
    @Column(nullable = false)
    private String apellidos;
    @Column(nullable = false)
    private String telefono;
    @Column(nullable = false)
    private String email;
    @Column(nullable = false)
    private String contrasena;
    @Column(nullable = false)
    private Boolean activo;


}
