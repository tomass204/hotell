package cl.hotel.clientes.repository;

import cl.hotel.clientes.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository //para que el ClienteRepository se pa que sera un repositorio
public interface ClienteRepository extends JpaRepository<Cliente,Long> {
//Aquí estamos heredando de JpaRepository, que es una interfaz de Spring Data JPA,
//hace que el repositorio tenga los metodos de CRUD

    Optional<Cliente> findByRun(String run);
    //Estos método Opcional sirve para hacer login o validación de acceso osea busca un cliente por su run o contrasena
    // o ver si esta activo

    Optional<Cliente> findByRunAndContrasenaAndActivoTrue(String run, String contrasena);



}
