package cl.hotel.clientes.service;


import cl.hotel.clientes.model.Cliente;
import cl.hotel.clientes.repository.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.Optional;

@Service//Define la clase como un servicio
public class ClienteService {

    @Autowired
    private ClienteRepository repository;

    public Cliente iniciarSession(String run, String contrasena){
        //Este método público recibe el RUT y la contraseña del cliente para intentar iniciar sesión.
        Optional<Cliente> clienteOptional = repository.findByRunAndContrasenaAndActivoTrue(run,contrasena);
        //Busca un cliente cuyo RUT y contrasena coincidan, y además esté activo (activo = true)
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("Error al iniciar session.");
            //verifica si no se encontró un cliente, si no hay concidencia lanzaria un error
        }
        return repository.save(clienteOptional.get());
        //lo guarda en la base de datos
    }


    public Cliente crear(Map<String, Object> map_cliente) {
        //Este método público recibe un mapa con los datos del cliente para crear un nuevo cliente.
        Cliente cliente = new Cliente();
        cliente.setRun(String.valueOf(map_cliente.get("run")));
        cliente.setNombres(String.valueOf(map_cliente.get("nombres")));
        cliente.setApellidos(String.valueOf(map_cliente.get("apellidos")));
        cliente.setEmail(String.valueOf(map_cliente.get("email")));
        cliente.setTelefono(String.valueOf(map_cliente.get("telefono")));
        cliente.setContrasena(String.valueOf(map_cliente.get("contrasena")));
        cliente.setClienteID(null);
        cliente.setActivo(true);
        return repository.save(cliente);
    }

    public Cliente editar(Map<String, Object> map_cliente, Long clienteID) {
        //Busca un cliente por su ID, si no existe lanza un error,si existe, actualiza sus datos con los nuevos valores.
        //Guarda y devuelve el cliente actualizado.
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe la habitación.");
        }
        Cliente cliente = clienteOptional.get();
        cliente.setRun(String.valueOf(map_cliente.get("run")));
        cliente.setNombres(String.valueOf(map_cliente.get("nombres")));
        cliente.setApellidos(String.valueOf(map_cliente.get("apellidos")));
        cliente.setEmail(String.valueOf(map_cliente.get("email")));
        cliente.setTelefono(String.valueOf(map_cliente.get("telefono")));
        cliente.setContrasena(String.valueOf(map_cliente.get("contrasena")));
        return repository.save(cliente);
    }

    public Cliente ver(Long clienteID) {
        //Busca un cliente por su ID, si no existe lanza error,si existe, guarda de nuevo el cliente
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        return repository.save(clienteOptional.get());
    }

    public Cliente verPorRun(String run) {
        //Busca un cliente por su RUN, si no existe lanza error,si existe, guarda y retorna el cliente
        Optional<Cliente> clienteOptional = repository.findByRun(run);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        return repository.save(clienteOptional.get());
    }






    //activar y desactivar buscan un cliente por su ID, verifican que exista
    //cambian el campo activo a true o false respectivamente
    public Cliente activar(Long clienteID) {
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        Cliente cliente = clienteOptional.get();
        cliente.setActivo(true);
        return repository.save(cliente);
    }

    public Cliente desactivar(Long clienteID) {
        Optional<Cliente> clienteOptional = repository.findById(clienteID);
        if (!clienteOptional.isPresent()) {
            throw new RuntimeException("No existe el cliente.");
        }
        Cliente cliente = clienteOptional.get();
        cliente.setActivo(false);
        return repository.save(cliente);
    }



}
