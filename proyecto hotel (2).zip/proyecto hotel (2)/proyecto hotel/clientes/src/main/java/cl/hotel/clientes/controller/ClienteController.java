package cl.hotel.clientes.controller;


import cl.hotel.clientes.model.Cliente;
import cl.hotel.clientes.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController//Marca la clase como un controller
@RequestMapping("/api/hotel/v1/clientes")//Define la ruta base de la API
public class ClienteController {

    @Autowired
    private ClienteService service;

    @PostMapping("/iniciar-session")//define como va iniciar session el usuario con run y contrasena
    public ResponseEntity<Cliente> iniciarSession(@RequestParam(name = "run", required = true) String run, 
                                                  @RequestParam(name = "contrasena", required = true) String contrasena){
        return ResponseEntity.ok(service.iniciarSession(run,contrasena));
        //Devuelve una respuesta HTTP 200 OK con el resultado de la operación
    }

    @PostMapping        
    //maneja un Post para crear un cliente y los pasa al servicio para guardarlos en la base de datos.
    public ResponseEntity<Cliente> crear(@RequestBody Map<String, Object> cliente) {
        return ResponseEntity.ok(service.crear(cliente)); 
    }

    @PutMapping("/{clienteID}") 
    //Este método maneja una solicitud HTTP PUT para editar o actualizar un cliente en el sistema.
    public ResponseEntity<Cliente> editar(@RequestBody Map<String, Object> cliente, @PathVariable Long clienteID) {
        return ResponseEntity.ok(service.editar(cliente, clienteID));
    }

    @PatchMapping("/activar/{clienteID}")
    //Este método expone un endpoint PATCH para activar un cliente específico, es decir,
    //cambiar su estado a activo (true).
    public ResponseEntity<Cliente> activar(@PathVariable Long clienteID) {
        return ResponseEntity.ok(service.activar(clienteID));
    }

    @PatchMapping("/desactivar/{clienteID}")
    //Este método maneja una solicitud HTTP PATCH para desactivar un cliente, es decir,
    //cambiar su estado a inactivo (activo = false).
    public ResponseEntity<Cliente> desactivar(@PathVariable Long clienteID) {
        return ResponseEntity.ok(service.desactivar(clienteID));
    }

    @GetMapping("/{clienteID}")//maneja un Get Path para ver un cliente
    public ResponseEntity<Cliente> ver(@PathVariable Long clienteID) {
        return ResponseEntity.ok(service.ver(clienteID));
    }

    @GetMapping("/run/{run}")//maneja un Get Patch para ver un cliente por run
    public ResponseEntity<Cliente> verPorRun(@PathVariable String run) {
        return ResponseEntity.ok(service.verPorRun(run));
    }




}
