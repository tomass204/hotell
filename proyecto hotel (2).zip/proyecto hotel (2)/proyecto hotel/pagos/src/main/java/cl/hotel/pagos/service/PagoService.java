package cl.hotel.pagos.service;



import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.hotel.pagos.model.Pago;
import cl.hotel.pagos.repository.PagoRepository;

@Service
public class PagoService {

    @Autowired
    private PagoRepository repository;

    public Pago crear(Map<String, Object> map_pago) {
        Pago pago = new Pago();
        pago.setMedioPago(String.valueOf(map_pago.get("medioPago")));
        pago.setTotalPago(Integer.valueOf(String.valueOf(map_pago.get("totalPago"))));
        pago.setPagoID(null);
        pago.setPagado(false);
        return repository.save(pago);
    }

    public Pago editar(Map<String, Object> map_pago, Long pagoID) {
        Optional<Pago> pagoOptional = repository.findById(pagoID);
        if (!pagoOptional.isPresent()) {
            throw new RuntimeException("No existe el pago.");
        }
        Pago pago = pagoOptional.get();
        pago.setMedioPago(String.valueOf(map_pago.get("medioPago")));
        pago.setTotalPago(Integer.valueOf(String.valueOf(map_pago.get("totalPago"))));
        return repository.save(pago);
    }

    public Pago pagar(Long pagoID) {
        Optional<Pago> pagoOptional = repository.findById(pagoID);
        if (!pagoOptional.isPresent()) {
            throw new RuntimeException("No existe el pago.");
        }
        Pago pago = pagoOptional.get();
        pago.setPagado(true);
        return repository.save(pago);
    }


    public Pago ver(Long pagoID) {
        Optional<Pago> pagoOptional = repository.findById(pagoID);
        if (!pagoOptional.isPresent()) {
            throw new RuntimeException("No existe el pago.");
        }
        return repository.save(pagoOptional.get());
    }




}
