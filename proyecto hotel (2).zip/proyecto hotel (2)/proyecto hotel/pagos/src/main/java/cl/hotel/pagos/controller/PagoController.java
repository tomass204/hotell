package cl.hotel.pagos.controller;



import cl.hotel.pagos.model.Pago;
import cl.hotel.pagos.service.PagoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/pagos")
public class PagoController {

    @Autowired
    private PagoService service;

    @PostMapping
    public ResponseEntity<Pago> crear(@RequestBody Map<String, Object> pago) {
        return ResponseEntity.ok(service.crear(pago));
    }

    @PutMapping("/{pagoID}")
    public ResponseEntity<Pago> editar(@RequestBody Map<String, Object> pago, @PathVariable Long pagoID) {
        return ResponseEntity.ok(service.editar(pago, pagoID));
    }

    @PatchMapping("/pagar/{pagoID}")
    public ResponseEntity<Pago> pagar(@PathVariable Long pagoID) {
        return ResponseEntity.ok(service.pagar(pagoID));
    }


    @GetMapping("/{pagoID}")
    public ResponseEntity<Pago> ver(@PathVariable Long pagoID) {
        return ResponseEntity.ok(service.ver(pagoID));
    }



}
