package cl.hotel.habitaciones.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "habitaciones")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Habitacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "habitacion_id")
    private Long habitacionID;
    @Column(nullable = false)
    private String descripcion;
    @Column(nullable = false, name = "valor_por_dia")
    private Integer valorPorDia;
    @Column(nullable = false)
    private Integer numero;
    @Column(nullable = false)
    private Boolean activo;

}
