package cl.hotel.habitaciones.controller;


import cl.hotel.habitaciones.model.Habitacion;
import cl.hotel.habitaciones.service.HabitacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/habitaciones")
public class HabitacionController {

    @Autowired
    private HabitacionService service;

    @PostMapping
    public ResponseEntity<Habitacion> crear (@RequestBody Map<String,Object> habitacion){
        return ResponseEntity.ok(service.crear(habitacion));
    }

    @PutMapping("/{habitacionID}")
    public ResponseEntity<Habitacion> editar (@RequestBody Map<String,Object> habitacion, @PathVariable Long habitacionID){
        return ResponseEntity.ok(service.editar(habitacion, habitacionID));
    }

    @PatchMapping("/activar/{habitacionID}")
    public ResponseEntity<Habitacion> activar (@PathVariable Long habitacionID){
        return ResponseEntity.ok(service.activar(habitacionID));
    }

    @PatchMapping("/desactivar/{habitacionID}")
    public ResponseEntity<Habitacion> desactivar (@PathVariable Long habitacionID){
        return ResponseEntity.ok(service.desactivar(habitacionID));
    }

    @GetMapping("/{habitacionID}")
    public ResponseEntity<Habitacion> ver(@PathVariable Long habitacionID){
        return ResponseEntity.ok(service.ver(habitacionID));
    }


    @GetMapping("/listar")
    public ResponseEntity<List<Habitacion>> listahabitaciones(){
        return ResponseEntity.ok(service.listahabitaciones());
    }

    @GetMapping("/listar-activos")
    public ResponseEntity<List<Habitacion>> listaHabitacionesActivas(){
        return ResponseEntity.ok(service.listaHabitacionesActivas());
    }

}
