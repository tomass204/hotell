package cl.hotel.habitaciones.service;

import cl.hotel.habitaciones.model.Habitacion;
import cl.hotel.habitaciones.repository.HabitacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class HabitacionService {

    @Autowired
    private HabitacionRepository repository;

    public Habitacion crear(Map<String, Object> map_habitacion) {
        Habitacion habitacion = new Habitacion();
        habitacion.setDescripcion(String.valueOf(map_habitacion.get("descripcion")));
        habitacion.setValorPorDia(Integer.valueOf(String.valueOf(map_habitacion.get("valorPorDia"))));
        habitacion.setNumero(Integer.valueOf(String.valueOf(map_habitacion.get("numero"))));
        habitacion.setHabitacionID(null);
        habitacion.setActivo(true);
        return repository.save(habitacion);
    }

    public Habitacion editar(Map<String, Object> map_habitacion, Long habitacionID) {
        Optional<Habitacion> habitacionOptional = repository.findById(habitacionID);
        if (!habitacionOptional.isPresent()) {
            throw new RuntimeException("No existe la habitación.");
        }
        Habitacion habitacion = habitacionOptional.get();
        habitacion.setDescripcion(String.valueOf(map_habitacion.get("descripcion")));
        habitacion.setValorPorDia(Integer.valueOf(String.valueOf(map_habitacion.get("valorPorDia"))));
        habitacion.setNumero(Integer.valueOf(String.valueOf(map_habitacion.get("numero"))));
        return repository.save(habitacion);
    }

    public Habitacion ver(Long habitacionID) {
        Optional<Habitacion> habitacionOptional = repository.findById(habitacionID);
        if (!habitacionOptional.isPresent()) {
            throw new RuntimeException("No existe la habitación.");
        }
        return repository.save(habitacionOptional.get());
    }

    public Habitacion activar(Long habitacionID) {
        Optional<Habitacion> habitacionOptional = repository.findById(habitacionID);
        if (!habitacionOptional.isPresent()) {
            throw new RuntimeException("No existe la habitación.");
        }
        Habitacion habitacion = habitacionOptional.get();
        habitacion.setActivo(true);
        return repository.save(habitacion);
    }

    public Habitacion desactivar(Long habitacionID) {
        Optional<Habitacion> habitacionOptional = repository.findById(habitacionID);
        if (!habitacionOptional.isPresent()) {
            throw new RuntimeException("No existe la habitación.");
        }
        Habitacion habitacion = habitacionOptional.get();
        habitacion.setActivo(false);
        return repository.save(habitacion);
    }

    public List<Habitacion> listahabitaciones() {
        return repository.findAll();
    }

    public List<Habitacion> listaHabitacionesActivas() {
        return repository.findAllByActivoTrue();
    }


}
