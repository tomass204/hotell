package cl.hotel.autos.controller;

import cl.hotel.autos.model.Auto;
import cl.hotel.autos.service.AutoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/hotel/v1/autos")
public class AutoController {

    @Autowired
    private AutoService service;

    @PostMapping
    public ResponseEntity<Auto> crear (@RequestBody Map<String,Object> auto){
        return ResponseEntity.ok(service.crear(auto));
    }

    @PutMapping("/{autoID}")
    public ResponseEntity<Auto> editar (@RequestBody Map<String,Object> auto, @PathVariable Long autoID){
        return ResponseEntity.ok(service.editar(auto, autoID));
    }

    @PatchMapping("/activar/{autoID}")
    public ResponseEntity<Auto> activar (@PathVariable Long autoID){
        return ResponseEntity.ok(service.activar(autoID));
    }

    @PatchMapping("/desactivar/{autoID}")
    public ResponseEntity<Auto> desactivar (@PathVariable Long autoID){
        return ResponseEntity.ok(service.desactivar(autoID));
    }

    @GetMapping("/{autoID}")
    public ResponseEntity<Auto> ver(@PathVariable Long autoID){
        return ResponseEntity.ok(service.ver(autoID));
    }



    
    @GetMapping("/listar")//Lista todos los autos
    public ResponseEntity<List<Auto>> listaAutos(){
        return ResponseEntity.ok(service.listaAutos());
    }

    @GetMapping("/listar-activos")//Busca autos que esten activos y los lista 
    public ResponseEntity<List<Auto>> listaAutosActivos(){
        return ResponseEntity.ok(service.listaAutosActivos());
    }

}
